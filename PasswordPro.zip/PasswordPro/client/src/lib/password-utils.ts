import { apiRequest } from "@/lib/queryClient";

interface PasswordRequirements {
  length: boolean;
  uppercase: boolean;
  lowercase: boolean;
  number: boolean;
  special: boolean;
  notCommon: boolean;
}

interface PasswordStrength {
  score: number;
  label: string;
  color: string;
  percentage: number;
  textColor: string;
}

export function checkRequirements(password: string): PasswordRequirements {
  return {
    length: password.length >= 8,
    uppercase: /[A-Z]/.test(password),
    lowercase: /[a-z]/.test(password),
    number: /[0-9]/.test(password),
    special: /[^A-Za-z0-9]/.test(password),
    notCommon: true // Default to true, will be updated by API check
  };
}

export function checkPasswordStrength(
  requirements: PasswordRequirements,
  passwordLength: number
): PasswordStrength {
  // Calculate score (0-4)
  let score = 0;
  
  if (passwordLength > 0) {
    // Start with 1 if anything is entered
    score = 1;
    
    // Add points for meeting requirements
    const meetsRequirements = Object.values(requirements).filter(Boolean).length;
    
    if (meetsRequirements >= 3) score = 2;
    if (meetsRequirements >= 4) score = 3;
    if (meetsRequirements === 6) score = 4;
    
    // Penalize for short passwords regardless of complexity
    if (passwordLength < 6) score = Math.min(score, 1);
    if (passwordLength < 4) score = 0;
  }

  // Map score to a strength object
  switch (score) {
    case 0:
      return {
        score: 0,
        label: "Weak",
        color: "bg-red-500",
        percentage: 20,
        textColor: "text-red-500"
      };
    case 1:
      return {
        score: 1,
        label: "Weak",
        color: "bg-red-500",
        percentage: 25,
        textColor: "text-red-500"
      };
    case 2:
      return {
        score: 2,
        label: "Moderate",
        color: "bg-amber-500",
        percentage: 50,
        textColor: "text-amber-500"
      };
    case 3:
      return {
        score: 3,
        label: "Strong",
        color: "bg-emerald-500",
        percentage: 75,
        textColor: "text-emerald-500"
      };
    case 4:
      return {
        score: 4,
        label: "Very Strong",
        color: "bg-emerald-500",
        percentage: 100,
        textColor: "text-emerald-500"
      };
    default:
      return {
        score: 0,
        label: "Weak",
        color: "bg-red-500",
        percentage: 20,
        textColor: "text-red-500"
      };
  }
}

export async function isCommonPassword(password: string): Promise<boolean> {
  try {
    const response = await apiRequest("POST", "/api/password/common", { password });
    const data = await response.json();
    return data.isCommon;
  } catch (error) {
    console.error("Error checking if password is common:", error);
    return false;
  }
}
