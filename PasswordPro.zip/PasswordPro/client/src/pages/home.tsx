import PasswordStrengthChecker from "@/components/password-strength-checker";
import { FaHeart, FaStar, FaCloud } from "react-icons/fa";

export default function Home() {
  return (
    <div className="cute-pattern min-h-screen flex flex-col items-center justify-center p-4 py-10 relative overflow-hidden">
      {/* Cute decorative elements */}
      <div className="absolute top-10 right-10 md:right-20 text-pink-300 animate-float" style={{ animationDelay: "0s" }}>
        <FaHeart className="text-4xl" />
      </div>
      <div className="absolute top-20 right-16 md:right-36 text-purple-300 animate-float" style={{ animationDelay: "0.5s" }}>
        <FaStar className="text-3xl" />
      </div>
      <div className="absolute bottom-16 left-12 md:left-24 text-pink-300 animate-float" style={{ animationDelay: "1s" }}>
        <FaStar className="text-3xl" />
      </div>
      <div className="absolute bottom-24 left-20 md:left-36 text-purple-300 animate-float" style={{ animationDelay: "1.5s" }}>
        <FaHeart className="text-4xl" />
      </div>
      <div className="absolute top-40 left-10 text-blue-200 animate-float" style={{ animationDelay: "0.7s" }}>
        <FaCloud className="text-5xl" />
      </div>
      <div className="absolute bottom-20 right-10 text-blue-200 animate-float" style={{ animationDelay: "1.2s" }}>
        <FaCloud className="text-5xl" />
      </div>
      
      {/* Floating clouds */}
      <div className="absolute -top-10 left-1/4 opacity-30 animate-float" style={{ animationDuration: "6s" }}>
        <div className="bg-white w-24 h-10 rounded-full"></div>
      </div>
      <div className="absolute top-1/4 -right-10 opacity-30 animate-float" style={{ animationDuration: "8s", animationDelay: "1s" }}>
        <div className="bg-white w-32 h-12 rounded-full"></div>
      </div>
      
      {/* Header */}
      <div className="mb-8 text-center max-w-2xl">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-pink-100 flex items-center justify-center border-4 border-pink-200 animate-bounce-slow">
            <FaHeart className="text-3xl text-pink-400" />
          </div>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold mb-3 bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text">
          Cute Password Helper
        </h1>
        <p className="text-pink-700 max-w-md mx-auto font-medium">
          Make your passwords super strong and keep your accounts safe! 💖
        </p>
      </div>
      
      {/* Password checker component */}
      <PasswordStrengthChecker />
      
      {/* Footer */}
      <div className="mt-10 text-center text-pink-400 text-sm">
        <p>Stay safe online with adorable password protection! 🌸</p>
        <p className="mt-2">© {new Date().getFullYear()} <span className="text-purple-400">Cute Password Checker</span> 💜</p>
      </div>
    </div>
  );
}
