import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import PasswordInput from "@/components/ui/password-input";
import ProgressBar from "@/components/ui/progress-bar";
import { 
  checkPasswordStrength, 
  checkRequirements, 
  isCommonPassword 
} from "@/lib/password-utils";
import { useQuery } from "@tanstack/react-query";
import { 
  FaCheck, FaTimes, FaInfoCircle, FaHeart,
  FaCat, FaDog, FaSmile, FaMeh, FaFrown, FaGift, 
  FaStar, FaKey, FaCrown, FaMagic, FaRegStar
} from "react-icons/fa";

export default function PasswordStrengthChecker() {
  const [password, setPassword] = useState("");
  const [requirements, setRequirements] = useState({
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    special: false,
    notCommon: true
  });
  const [strength, setStrength] = useState({
    score: 0,
    label: "Weak",
    color: "bg-red-500",
    percentage: 20,
    textColor: "text-red-500"
  });

  // Check if password is in common passwords list
  const { data: isCommon } = useQuery({
    queryKey: ['/api/password/common', password],
    queryFn: async () => {
      if (!password) return false;
      return await isCommonPassword(password);
    },
    enabled: !!password && password.length > 0
  });

  useEffect(() => {
    if (password === "") {
      setRequirements({
        length: false,
        uppercase: false,
        lowercase: false,
        number: false,
        special: false,
        notCommon: true
      });
      setStrength({
        score: 0,
        label: "Weak",
        color: "bg-red-500",
        percentage: 20,
        textColor: "text-red-500"
      });
      return;
    }

    // Check password requirements
    const reqs = checkRequirements(password);
    
    // Update common password check based on API response
    if (isCommon !== undefined) {
      reqs.notCommon = !isCommon;
    }
    
    setRequirements(reqs);

    // Check overall strength
    const strengthResult = checkPasswordStrength(reqs, password.length);
    setStrength(strengthResult);
  }, [password, isCommon]);

  // Function to get cute security icon based on strength score
  const getSecurityIcon = () => {
    switch (strength.score) {
      case 0:
      case 1:
        return <FaFrown className="text-pink-500 text-xl animate-bounce-slow" />;
      case 2:
        return <FaMeh className="text-amber-400 text-xl" />;
      case 3:
      case 4:
        return <FaSmile className="text-emerald-400 text-xl animate-bounce-slow" />;
      default:
        return <FaFrown className="text-pink-500 text-xl" />;
    }
  };
  
  // Get cute mascot based on password strength
  const getMascot = () => {
    switch (strength.score) {
      case 0:
      case 1:
        return <FaCat className="text-4xl text-pink-400" />;
      case 2:
        return <FaDog className="text-4xl text-amber-400" />;
      case 3:
      case 4:
        return <FaCrown className="text-4xl text-purple-400" />;
      default:
        return <FaCat className="text-4xl text-pink-400" />;
    }
  };

  return (
    <Card className="cute-card max-w-md w-full">
      <CardContent className="p-6 md:p-8">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-3">
            <div className="p-3 rounded-full bg-pink-100 inline-block border-4 border-pink-200 animate-bounce-slow">
              {getMascot()}
            </div>
          </div>
          <h1 className="text-2xl font-semibold mb-2 bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text">
            Password Cuteness Check
          </h1>
          <p className="text-pink-600">Make a super strong password for your account! 💕</p>
        </div>

        <div className="space-y-6">
          <PasswordInput 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <div className="bg-pink-50 rounded-2xl p-4 border-2 border-pink-100">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center">
                {getSecurityIcon()}
                <span className="text-sm font-medium text-pink-700 ml-2">Password Strength</span>
              </div>
              <span className={`text-sm font-semibold ${strength.textColor} px-3 py-1 rounded-full bg-opacity-20 flex items-center`} 
                style={{ backgroundColor: `${strength.color.replace('bg-', 'rgba(')}, 0.1)` }}>
                {strength.score >= 3 && <FaStar className="mr-1" />}
                {strength.label}
                {strength.score >= 3 && <FaStar className="ml-1" />}
              </span>
            </div>
            <ProgressBar 
              percentage={strength.percentage} 
              color={strength.color} 
            />
            
            {/* Cute password strength visualization */}
            <div className="flex justify-between mt-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <div key={star} className="transition-all duration-300">
                  {strength.score >= star-1 ? (
                    <FaStar className={`text-pink-400 ${strength.score === star-1 ? 'animate-bounce-slow' : ''}`} />
                  ) : (
                    <FaRegStar className="text-gray-300" />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-purple-50 rounded-2xl p-4 border-2 border-purple-100">
            <h3 className="text-md font-medium text-purple-800 mb-3 flex items-center">
              <FaKey className="mr-2 text-purple-500" />
              Password Magic Ingredients 🪄
            </h3>
            <ul className="space-y-2 grid grid-cols-1 md:grid-cols-2 gap-2">
              <RequirementItem 
                isValid={requirements.length} 
                text="At least 8 characters long" 
              />
              <RequirementItem 
                isValid={requirements.uppercase} 
                text="Contains uppercase letters (A-Z)" 
              />
              <RequirementItem 
                isValid={requirements.lowercase} 
                text="Contains lowercase letters (a-z)" 
              />
              <RequirementItem 
                isValid={requirements.number} 
                text="Contains at least one number (0-9)" 
              />
              <RequirementItem 
                isValid={requirements.special} 
                text="Contains at least one special character (@#$%&*!)" 
              />
              <RequirementItem 
                isValid={requirements.notCommon} 
                text="Not a commonly used password" 
              />
            </ul>
          </div>

          <Alert className="bg-blue-50 rounded-2xl p-4 border-2 border-blue-100">
            <AlertDescription>
              <h3 className="text-md font-medium text-blue-600 mb-2 flex items-center">
                <FaGift className="mr-2 text-blue-400" />
                Tips for a Super-Duper Password ✨
              </h3>
              <ul className="space-y-1 text-sm text-blue-600">
                <TipItem text="Mix letters, numbers, and symbols for extra power!" />
                <TipItem text="Avoid using your birthday or name (too easy to guess!)" />
                <TipItem text="Try a secret phrase with random capitals and numbers" />
                <TipItem text="Use different passwords for all your accounts" />
              </ul>
            </AlertDescription>
          </Alert>
          
          {strength.score <= 1 && password.length > 0 && (
            <Alert className="bg-pink-50 rounded-2xl p-4 border-2 border-pink-200">
              <AlertDescription className="flex items-start">
                <FaCat className="text-pink-500 mt-1 mr-2 flex-shrink-0 text-xl" />
                <span className="text-sm text-pink-600">
                  Oopsie! This password needs more magic to keep your account safe! Try adding some special characters or making it longer! 🎀
                </span>
              </AlertDescription>
            </Alert>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function RequirementItem({ isValid, text }: { isValid: boolean, text: string }) {
  return (
    <li className="flex items-start gap-2">
      <div className={`mt-0.5 ${isValid ? "text-pink-500" : "text-gray-400"}`}>
        {isValid ? (
          <FaHeart size={14} className="animate-bounce-slow" />
        ) : (
          <FaRegStar size={14} />
        )}
      </div>
      <span className={`text-sm ${isValid ? "text-purple-700" : "text-gray-500"}`}>{text}</span>
    </li>
  );
}

function TipItem({ text }: { text: string }) {
  return (
    <li className="flex items-start gap-2">
      <FaStar className="text-blue-400 mt-0.5 flex-shrink-0" size={14} />
      <span>{text}</span>
    </li>
  );
}
