interface ProgressBarProps {
  percentage: number;
  color: string;
}

export default function ProgressBar({ percentage, color }: ProgressBarProps) {
  return (
    <div className="h-4 w-full bg-gray-200 rounded-full overflow-hidden relative">
      {/* Cute decorative background segments */}
      <div className="h-full w-full absolute left-0 top-0 opacity-20">
        <div className={`h-full w-1/5 ${color} float-left rounded-l-full`}></div>
        <div className={`h-full w-1/5 ${color} float-left ml-[2px]`}></div>
        <div className={`h-full w-1/5 ${color} float-left ml-[2px]`}></div>
        <div className={`h-full w-1/5 ${color} float-left ml-[2px]`}></div>
        <div className={`h-full w-1/5 ${color} float-left ml-[2px] rounded-r-full`}></div>
      </div>
      
      {/* Cute decorative dots */}
      <div className="absolute top-0 left-0 w-full h-full flex justify-between px-2 items-center z-10 pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <div 
            key={i} 
            className={`w-2 h-2 rounded-full bg-white opacity-70 transition-transform duration-300 ${percentage >= (i+1) * 20 ? 'scale-100' : 'scale-0'}`}
            style={{ transform: percentage >= (i+1) * 20 ? 'scale(1)' : 'scale(0)' }}
          />
        ))}
      </div>
      
      {/* Animated progress bar */}
      <div
        className={`h-full ${color} rounded-full transition-all duration-500 relative z-5`}
        style={{ 
          width: `${percentage}%`,
          boxShadow: `0 0 10px ${color.replace('bg-', 'rgba(').replace(')', ', 0.5)')}`,
          background: `linear-gradient(45deg, ${color.replace('bg-', 'var(--')})} 25%, 
                      ${color.replace('bg-', 'rgba(').replace(')', ', 0.8)')} 25%, 
                      ${color.replace('bg-', 'rgba(').replace(')', ', 0.8)')} 50%, 
                      ${color.replace('bg-', 'var(--')})} 50%, 
                      ${color.replace('bg-', 'var(--')})} 75%, 
                      ${color.replace('bg-', 'rgba(').replace(')', ', 0.8)')} 75%, 
                      ${color.replace('bg-', 'rgba(').replace(')', ', 0.8)')})`,
          backgroundSize: '1rem 1rem',
          animation: 'progress-animation 1s linear infinite'
        }}
      ></div>

    </div>
  );
}
