import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FaEye, FaEyeSlash, FaHeart, FaStar } from "react-icons/fa";

interface PasswordInputProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function PasswordInput({ value, onChange }: PasswordInputProps) {
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };
  
  // Add visual effect when typing
  const [isTyping, setIsTyping] = useState(false);
  
  useEffect(() => {
    if (value) {
      setIsTyping(true);
      const timer = setTimeout(() => setIsTyping(false), 300);
      return () => clearTimeout(timer);
    }
  }, [value]);

  return (
    <div className="relative">
      <Label 
        htmlFor="password" 
        className="block text-sm font-medium text-pink-600 mb-1 flex items-center"
      >
        <FaHeart className="mr-1 text-pink-500" size={14} />
        Your Secret Password
      </Label>
      <div className={`relative transition-all duration-300 ${isTyping ? 'animate-pulse-shadow' : ''}`}>
        <div className="absolute left-3 inset-y-0 flex items-center pointer-events-none">
          <div className={`transition-all duration-300 ${isFocused ? 'text-pink-500' : 'text-pink-300'}`}>
            <FaHeart size={16} className={isFocused ? 'animate-bounce-slow' : ''} />
          </div>
        </div>
        <Input
          type={passwordVisible ? "text" : "password"}
          id="password"
          className={`w-full pl-10 pr-12 py-3 rounded-full border-2 ${
            isFocused ? 'border-pink-400 ring-2 ring-pink-200' : 'border-pink-200'
          } focus:border-pink-400 focus:ring-pink-200 transition-all`}
          placeholder="Type your magical password..."
          value={value}
          onChange={onChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
        />
        <button
          type="button"
          onClick={togglePasswordVisibility}
          className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-full transition-colors ${
            passwordVisible ? 'bg-pink-100 text-pink-500' : 'text-pink-400 hover:text-pink-500'
          }`}
          aria-label={passwordVisible ? "Hide password" : "Show password"}
        >
          {passwordVisible ? (
            <FaEyeSlash size={16} />
          ) : (
            <FaEye size={16} />
          )}
        </button>
      </div>
      
      {/* Cute Password character counter */}
      <div className="absolute right-0 -bottom-6 text-xs flex items-center">
        {value.length > 0 && (
          <span className={value.length >= 8 ? 'text-green-500 flex items-center' : 'text-pink-500 flex items-center'}>
            {value.length >= 8 && <FaStar className="mr-1" />}
            {value.length} character{value.length !== 1 ? 's' : ''}
            {value.length >= 8 && <FaStar className="ml-1" />}
          </span>
        )}
      </div>
    </div>
  );
}
