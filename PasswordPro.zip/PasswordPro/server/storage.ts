import { db } from '@db';
import { commonPasswords } from '@shared/schema';
import { eq } from 'drizzle-orm';

export const storage = {
  // Check if a password is in the common passwords list
  async isCommonPassword(password: string): Promise<boolean> {
    if (!password) return false;

    const lowercasePassword = password.toLowerCase();
    
    const result = await db.query.commonPasswords.findFirst({
      where: eq(commonPasswords.password, lowercasePassword)
    });
    
    return !!result;
  }
};
