import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint to check if a password is common
  app.post('/api/password/common', async (req, res) => {
    try {
      const { password } = req.body;
      
      if (!password) {
        return res.status(400).json({ 
          message: "Password is required", 
          isCommon: false 
        });
      }
      
      const isCommon = await storage.isCommonPassword(password);
      
      return res.json({ isCommon });
    } catch (error) {
      console.error("Error checking password:", error);
      return res.status(500).json({ 
        message: "Internal server error", 
        isCommon: false
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
