import { db } from "./index";
import * as schema from "@shared/schema";

// List of common passwords to seed the database with
const COMMON_PASSWORDS = [
  'password', '123456', 'qwerty', 'admin', 'welcome',
  '123456789', '12345678', 'abc123', 'football', 'monkey',
  'letmein', '111111', 'mustang', 'access', 'shadow',
  'master', 'michael', 'superman', 'password1', 'baseball',
  '000000', '654321', 'iloveyou', 'sunshine', 'charlie',
  'donald', 'qwerty123', 'dragon', 'welcome1', 'jesus',
  'ninja', 'trustno1', 'princess', 'passw0rd', 'freedom',
  'hunter', 'batman', 'summer', 'winter', 'autumn',
  'spring', 'marvel', 'starwars', 'harley', 'pepper'
];

async function seed() {
  try {
    // Check if we already have common passwords in the database
    const existingPasswords = await db.query.commonPasswords.findMany();
    
    if (existingPasswords.length === 0) {
      console.log("Seeding common passwords...");
      
      // Create array of password objects for bulk insert
      const passwordsToInsert = COMMON_PASSWORDS.map(password => ({
        password: password.toLowerCase()
      }));
      
      // Insert common passwords in batches to avoid too many values error
      const batchSize = 20;
      for (let i = 0; i < passwordsToInsert.length; i += batchSize) {
        const batch = passwordsToInsert.slice(i, i + batchSize);
        await db.insert(schema.commonPasswords).values(batch);
      }
      
      console.log(`Seeded ${COMMON_PASSWORDS.length} common passwords successfully.`);
    } else {
      console.log(`Common passwords already exist (${existingPasswords.length} entries), skipping seed.`);
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
