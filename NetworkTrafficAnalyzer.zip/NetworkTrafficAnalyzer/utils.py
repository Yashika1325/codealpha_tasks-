#!/usr/bin/env python3
"""
Utilities Module - Provides utility functions for network sniffer
"""
import logging
import os
import sys
import socket
import platform
import subprocess
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)


def get_timestamp():
    """Get current timestamp as a formatted string
    
    Returns:
        str: Formatted timestamp string
    """
    return datetime.now().strftime('%Y%m%d_%H%M%S')


def check_privileges():
    """Check if the script has the necessary privileges
    
    Returns:
        bool: True if elevated privileges, False otherwise
    """
    if os.name == 'nt':  # Windows
        try:
            return bool(subprocess.check_output('net session', shell=True, stderr=subprocess.DEVNULL))
        except subprocess.CalledProcessError:
            return False
    else:  # Linux/Mac
        return os.geteuid() == 0


def get_default_output_file():
    """Generate a default output file name based on timestamp
    
    Returns:
        str: Default output file name
    """
    timestamp = get_timestamp()
    return f"captured_packets_{timestamp}.pcap"


def get_ip_info(host):
    """Get IP information for a hostname
    
    Args:
        host (str): Hostname to lookup
        
    Returns:
        dict: Dictionary with IP information
    """
    info = {
        'hostname': host,
        'ipv4': None,
        'ipv6': None
    }
    
    try:
        # Get IPv4 address
        info['ipv4'] = socket.gethostbyname(host)
        
        # Try to get IPv6 address
        addrinfo = socket.getaddrinfo(host, None)
        for addr in addrinfo:
            if addr[0] == socket.AF_INET6:
                info['ipv6'] = addr[4][0]
                break
    
    except Exception as e:
        logger.error(f"Error getting IP info for {host}: {e}")
    
    return info


def print_system_info():
    """Print system information for debugging purposes"""
    print("\nSystem Information:")
    print(f"  OS: {platform.system()} {platform.release()}")
    print(f"  Python: {platform.python_version()}")
    
    try:
        hostname = socket.gethostname()
        print(f"  Hostname: {hostname}")
        
        # Get IP address
        try:
            ip = socket.gethostbyname(hostname)
            print(f"  IP Address: {ip}")
        except:
            print("  IP Address: Unable to determine")
        
        # Check network interfaces
        if os.name != 'nt':  # Unix-like systems
            try:
                interfaces = os.listdir('/sys/class/net/')
                print(f"  Network Interfaces: {', '.join(interfaces)}")
            except:
                pass
    
    except Exception as e:
        logger.error(f"Error getting system info: {e}")


def format_mac_address(mac):
    """Format MAC address with colons
    
    Args:
        mac (str): MAC address in any format
        
    Returns:
        str: Formatted MAC address
    """
    # Remove any non-hexadecimal characters
    mac = ''.join(c for c in mac if c.isalnum())
    
    # Format with colons
    return ':'.join(mac[i:i+2] for i in range(0, len(mac), 2))


def human_readable_size(size_bytes):
    """Convert bytes to human-readable format
    
    Args:
        size_bytes (int): Size in bytes
        
    Returns:
        str: Human-readable size string
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    
    size_kb = size_bytes / 1024
    if size_kb < 1024:
        return f"{size_kb:.2f} KB"
    
    size_mb = size_kb / 1024
    if size_mb < 1024:
        return f"{size_mb:.2f} MB"
    
    size_gb = size_mb / 1024
    return f"{size_gb:.2f} GB"


def is_private_ip(ip):
    """Check if an IP address is private
    
    Args:
        ip (str): IP address to check
        
    Returns:
        bool: True if private, False otherwise
    """
    try:
        # Convert IP to integer for easier comparison
        octets = ip.split('.')
        if len(octets) != 4:
            return False
        
        # Check if it matches private IP ranges
        if octets[0] == '10':  # 10.0.0.0/8
            return True
        elif octets[0] == '172' and 16 <= int(octets[1]) <= 31:  # 172.16.0.0/12
            return True
        elif octets[0] == '192' and octets[1] == '168':  # 192.168.0.0/16
            return True
        elif ip.startswith('127.'):  # 127.0.0.0/8
            return True
        
        return False
    except:
        return False
