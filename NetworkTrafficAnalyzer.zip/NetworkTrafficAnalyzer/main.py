#!/usr/bin/env python3
"""
Main entry point for the network sniffer application with Flask web interface
"""
import os
import sys
import logging
import threading
import time
import json
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, Response, session
from network_sniffer import NetworkSniffer
from packet_capture import PacketCapture
from packet_filter import PacketFilter
from packet_analyzer import PacketAnalyzer
from packet_statistics import PacketStatistics
import utils

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "network_sniffer_secret")

# Global variables
capture_thread = None
stop_capture = threading.Event()
captured_packets = []
packet_details_cache = {}
selected_interface = None

# Initialize components
packet_capture = PacketCapture()
packet_filter = PacketFilter()
packet_analyzer = PacketAnalyzer()
packet_statistics = PacketStatistics()

def capture_packets_thread(interface, count=0, timeout=None, filter_string=None):
    """Thread function for packet capture"""
    global captured_packets
    try:
        logger.info(f"Starting packet capture on interface: {interface}")
        captured_packets = []
        
        # Create a custom callback to store packets
        def custom_callback(packet):
            if not stop_capture.is_set():
                captured_packets.append(packet)
                return packet
            return None
        
        # Replace the packet_capture's callback with our custom one
        original_callback = packet_capture.packet_callback
        packet_capture.packet_callback = custom_callback
        
        # Start capturing packets
        packets = packet_capture.capture_packets(
            interface=interface,
            count=count,
            timeout=timeout,
            filter_string=filter_string
        )
        
        # Restore original callback
        packet_capture.packet_callback = original_callback
        
        logger.info(f"Captured {len(captured_packets)} packets")
        
    except Exception as e:
        logger.error(f"Error in capture thread: {e}")
        import traceback
        logger.error(traceback.format_exc())

@app.route('/')
def index():
    """Home page route"""
    return render_template('index.html')

@app.route('/interfaces')
def get_interfaces():
    """Get list of available network interfaces"""
    interfaces = packet_capture.get_interfaces()
    return jsonify(interfaces)

@app.route('/start_capture', methods=['POST'])
def start_capture():
    """Start packet capture"""
    global capture_thread, stop_capture, captured_packets, selected_interface
    
    if capture_thread and capture_thread.is_alive():
        return jsonify({"status": "error", "message": "Capture already in progress"})
    
    interface = request.form.get('interface')
    count = int(request.form.get('count', 0))
    timeout = int(request.form.get('timeout', 0)) if request.form.get('timeout') else None
    filter_string = request.form.get('filter', '')
    
    if not interface:
        return jsonify({"status": "error", "message": "No interface selected"})
    
    selected_interface = interface
    captured_packets = []
    stop_capture.clear()
    
    capture_thread = threading.Thread(
        target=capture_packets_thread,
        args=(interface, count, timeout, filter_string)
    )
    capture_thread.daemon = True
    capture_thread.start()
    
    return jsonify({"status": "success", "message": f"Started capture on {interface}"})

@app.route('/stop_capture')
def stop_capture_route():
    """Stop packet capture"""
    global stop_capture, capture_thread
    
    # Set the stop flag regardless
    stop_capture.set()
    packet_capture.stop_capture()
    
    if capture_thread and capture_thread.is_alive():
        # Wait for thread to finish
        capture_thread.join(timeout=3)
    
    # Always consider it successful for demo purposes
    return jsonify({
        "status": "success", 
        "message": "Capture stopped", 
        "packet_count": len(captured_packets)
    })

@app.route('/packets')
def get_packets():
    """Get captured packets list"""
    global captured_packets
    
    # Create a summary for each packet
    packet_summaries = []
    
    for i, packet in enumerate(captured_packets):
        details = packet_analyzer.get_packet_details(packet)
        
        # Format source and destination
        source = f"{details['src_ip']}:{details['src_port']}" if details['src_port'] else details['src_ip']
        destination = f"{details['dst_ip']}:{details['dst_port']}" if details['dst_port'] else details['dst_ip']
        
        packet_summaries.append({
            'id': i,
            'time': details['time'],
            'protocol': details['protocol'],
            'source': source,
            'destination': destination,
            'length': details['length'],
            'info': details['info']
        })
    
    return jsonify(packet_summaries)

@app.route('/packet/<int:packet_id>')
def get_packet_detail(packet_id):
    """Get detailed information for a single packet"""
    global captured_packets
    
    try:
        if 0 <= packet_id < len(captured_packets):
            packet = captured_packets[packet_id]
            details = packet_analyzer.get_packet_details(packet)
            
            # Convert packet to hex for display
            # We can't directly convert Scapy packet to JSON, so we extract what we need
            hexdump = packet.hexdump()
            
            # Try to get payload if available
            payload = None
            payload_hex = None
            payload_text = None
            
            try:
                payload = packet_analyzer.get_payload(packet)
                if payload:
                    # Convert payload to hex representation
                    payload_hex = ' '.join(f'{b:02x}' for b in payload)
                    # Try to decode as text
                    try:
                        payload_text = payload.decode('utf-8', errors='replace')
                    except:
                        payload_text = None
            except:
                pass
            
            response = {
                'id': packet_id,
                'details': details,
                'hexdump': hexdump.split('\n'),
                'summary': packet.summary(),
                'payload_hex': payload_hex,
                'payload_text': payload_text
            }
            
            return jsonify(response)
        else:
            return jsonify({"status": "error", "message": "Invalid packet ID"})
    except Exception as e:
        logger.error(f"Error getting packet details: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({"status": "error", "message": str(e)})

@app.route('/statistics')
def get_statistics():
    """Get statistics for captured packets"""
    global captured_packets
    
    if not captured_packets:
        return jsonify({"status": "error", "message": "No packets available for statistics"})
    
    try:
        # Generate statistics from captured packets
        packet_statistics.generate_statistics(captured_packets)
        
        # Basic statistics
        stats = {
            'total_packets': packet_statistics.stats['total_packets'],
            'total_bytes': packet_statistics.stats['total_bytes'],
            'avg_packet_size': packet_statistics.stats['total_bytes'] / packet_statistics.stats['total_packets'] if packet_statistics.stats['total_packets'] > 0 else 0,
            'protocol_counts': dict(packet_statistics.stats['protocol_counts']),
            'top_src_ips': dict(packet_statistics.stats['ip_counts']['src'].most_common(5)),
            'top_dst_ips': dict(packet_statistics.stats['ip_counts']['dst'].most_common(5)),
            'top_src_ports': dict(packet_statistics.stats['port_counts']['src'].most_common(5)),
            'top_dst_ports': dict(packet_statistics.stats['port_counts']['dst'].most_common(5))
        }
        
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error generating statistics: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({"status": "error", "message": str(e)})

@app.route('/hostinfo')
def get_host_info():
    """Get information about the local host"""
    host_info = packet_capture.get_host_info()
    return jsonify(host_info)

@app.route('/filter', methods=['POST'])
def apply_filter():
    """Apply filter to captured packets"""
    global captured_packets
    
    if not captured_packets:
        return jsonify({"status": "error", "message": "No packets available to filter"})
    
    filter_type = request.form.get('type')
    filter_value = request.form.get('value')
    
    try:
        filtered_packets = []
        
        if filter_type == 'protocol':
            filtered_packets = packet_filter.filter_by_protocol(captured_packets, filter_value)
        elif filter_type == 'ip':
            filtered_packets = packet_filter.filter_by_ip(captured_packets, filter_value)
        elif filter_type == 'port':
            port = int(filter_value)
            port_type = request.form.get('port_type')  # 'src', 'dst', or None for both
            filtered_packets = packet_filter.filter_by_port(captured_packets, port, port_type)
        elif filter_type == 'length':
            min_length = int(request.form.get('min_length', 0)) if request.form.get('min_length') else None
            max_length = int(request.form.get('max_length', 0)) if request.form.get('max_length') else None
            filtered_packets = packet_filter.filter_by_length(captured_packets, min_length, max_length)
        else:
            return jsonify({"status": "error", "message": "Invalid filter type"})
        
        # Update the global captured_packets list with the filtered packets
        captured_packets = filtered_packets
        
        return jsonify({
            "status": "success", 
            "message": f"Applied {filter_type} filter", 
            "packet_count": len(filtered_packets)
        })
    
    except Exception as e:
        logger.error(f"Error applying filter: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({"status": "error", "message": str(e)})

# For command-line use
if __name__ == "__main__":
    # Check if the script is running with root privileges (needed for packet capture)
    if os.name != 'nt' and os.geteuid() != 0:
        logger.warning("Warning: Network sniffing typically requires root privileges.")
        logger.warning("Some features may not work properly without sudo/root access.")
    
    # Create templates directory if it doesn't exist
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    # Create static directory for assets if it doesn't exist
    if not os.path.exists('static'):
        os.makedirs('static')
    
    # Use a different port if 5000 is already in use
    port = int(os.environ.get('PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=True)
