#!/usr/bin/env python3
"""
Packet Analyzer Module - Analyzes and displays packet information
"""
import logging
from scapy.all import IP, IPv6, TCP, UDP, ICMP, ARP
import textwrap
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)


class PacketAnalyzer:
    """Class for packet analysis operations"""
    
    def __init__(self):
        """Initialize the PacketAnalyzer class"""
        pass
    
    def get_packet_details(self, packet):
        """Extract detailed information from a packet
        
        Args:
            packet: The packet to analyze
            
        Returns:
            dict: Dictionary containing packet details
        """
        details = {
            'time': datetime.fromtimestamp(packet.time).strftime('%Y-%m-%d %H:%M:%S.%f'),
            'length': len(packet),
            'protocol': 'Unknown',
            'src_ip': None,
            'dst_ip': None,
            'src_port': None,
            'dst_port': None,
            'transport': None,
            'info': ''
        }
        
        # Determine packet type and extract information
        if IP in packet:
            details['protocol'] = 'IPv4'
            details['src_ip'] = packet[IP].src
            details['dst_ip'] = packet[IP].dst
            details['ttl'] = packet[IP].ttl
            
            if TCP in packet:
                details['transport'] = 'TCP'
                details['src_port'] = packet[TCP].sport
                details['dst_port'] = packet[TCP].dport
                details['flags'] = packet[TCP].flags
                details['info'] = f"TCP {details['src_port']} → {details['dst_port']} [Flags: {details['flags']}]"
                
                # Try to identify application layer protocol
                if details['dst_port'] == 80 or details['src_port'] == 80:
                    details['app_protocol'] = 'HTTP'
                elif details['dst_port'] == 443 or details['src_port'] == 443:
                    details['app_protocol'] = 'HTTPS'
                elif details['dst_port'] == 21 or details['src_port'] == 21:
                    details['app_protocol'] = 'FTP'
                elif details['dst_port'] == 22 or details['src_port'] == 22:
                    details['app_protocol'] = 'SSH'
                elif details['dst_port'] == 53 or details['src_port'] == 53:
                    details['app_protocol'] = 'DNS'
            
            elif UDP in packet:
                details['transport'] = 'UDP'
                details['src_port'] = packet[UDP].sport
                details['dst_port'] = packet[UDP].dport
                details['info'] = f"UDP {details['src_port']} → {details['dst_port']}"
                
                # Try to identify application layer protocol
                if details['dst_port'] == 53 or details['src_port'] == 53:
                    details['app_protocol'] = 'DNS'
                elif details['dst_port'] == 67 or details['dst_port'] == 68:
                    details['app_protocol'] = 'DHCP'
            
            elif ICMP in packet:
                details['transport'] = 'ICMP'
                details['type'] = packet[ICMP].type
                details['code'] = packet[ICMP].code
                details['info'] = f"ICMP Type: {details['type']}, Code: {details['code']}"
        
        elif IPv6 in packet:
            details['protocol'] = 'IPv6'
            details['src_ip'] = packet[IPv6].src
            details['dst_ip'] = packet[IPv6].dst
            
            if TCP in packet:
                details['transport'] = 'TCP'
                details['src_port'] = packet[TCP].sport
                details['dst_port'] = packet[TCP].dport
                details['flags'] = packet[TCP].flags
                details['info'] = f"TCP {details['src_port']} → {details['dst_port']} [Flags: {details['flags']}]"
            
            elif UDP in packet:
                details['transport'] = 'UDP'
                details['src_port'] = packet[UDP].sport
                details['dst_port'] = packet[UDP].dport
                details['info'] = f"UDP {details['src_port']} → {details['dst_port']}"
        
        elif ARP in packet:
            details['protocol'] = 'ARP'
            details['src_ip'] = packet[ARP].psrc
            details['dst_ip'] = packet[ARP].pdst
            details['src_mac'] = packet[ARP].hwsrc
            details['dst_mac'] = packet[ARP].hwdst
            op_type = "Request" if packet[ARP].op == 1 else "Reply"
            details['info'] = f"ARP {op_type}: {details['src_ip']} ({details['src_mac']}) → {details['dst_ip']} ({details['dst_mac']})"
        
        return details
    
    def display_packet_summary(self, packets):
        """Display summary information for packets
        
        Args:
            packets (list): List of packets to display
        """
        if not packets:
            logger.info("No packets to display")
            return
        
        logger.info(f"Displaying summary for {len(packets)} packets:")
        print("\n" + "=" * 100)
        print(f"{'No.':<5} {'Time':<23} {'Protocol':<10} {'Source':<25} {'Destination':<25} {'Info':<25}")
        print("-" * 100)
        
        for i, packet in enumerate(packets, 1):
            details = self.get_packet_details(packet)
            source = f"{details['src_ip']}:{details['src_port']}" if details['src_port'] else details['src_ip']
            destination = f"{details['dst_ip']}:{details['dst_port']}" if details['dst_port'] else details['dst_ip']
            
            # Truncate info if too long
            info = details['info']
            if len(info) > 25:
                info = info[:22] + "..."
            
            print(f"{i:<5} {details['time']:<23} {details['protocol']:<10} {source:<25} {destination:<25} {info:<25}")
        
        print("=" * 100 + "\n")
    
    def display_packet_details(self, packet):
        """Display detailed information for a single packet
        
        Args:
            packet: The packet to display
        """
        details = self.get_packet_details(packet)
        
        print("\n" + "=" * 80)
        print(f"PACKET DETAILS")
        print("=" * 80)
        print(f"Time: {details['time']}")
        print(f"Length: {details['length']} bytes")
        print(f"Protocol: {details['protocol']}")
        
        if details['src_ip']:
            print(f"Source IP: {details['src_ip']}")
        if details['dst_ip']:
            print(f"Destination IP: {details['dst_ip']}")
        if details['src_port']:
            print(f"Source Port: {details['src_port']}")
        if details['dst_port']:
            print(f"Destination Port: {details['dst_port']}")
        if details.get('ttl'):
            print(f"TTL: {details['ttl']}")
        if details.get('flags'):
            print(f"TCP Flags: {details['flags']}")
        if details.get('type'):
            print(f"ICMP Type: {details['type']}")
        if details.get('code'):
            print(f"ICMP Code: {details['code']}")
        if details.get('app_protocol'):
            print(f"Application Protocol: {details['app_protocol']}")
        
        print("-" * 80)
        print("Hexdump:")
        hexdump = packet.hexdump()
        for line in hexdump.split('\n'):
            print(line)
        
        print("-" * 80)
        print("Summary:", packet.summary())
        print("=" * 80 + "\n")
    
    def get_payload(self, packet):
        """Extract the payload from a packet
        
        Args:
            packet: The packet to extract payload from
            
        Returns:
            bytes: Payload data
        """
        payload = None
        
        if TCP in packet:
            payload = bytes(packet[TCP].payload)
        elif UDP in packet:
            payload = bytes(packet[UDP].payload)
        
        return payload
    
    def display_payload(self, packet, hex_view=True, text_view=True):
        """Display the payload of a packet
        
        Args:
            packet: The packet to display payload for
            hex_view (bool): Whether to display payload in hexadecimal
            text_view (bool): Whether to display payload as text
        """
        payload = self.get_payload(packet)
        
        if not payload:
            print("No payload data found")
            return
        
        print(f"Payload size: {len(payload)} bytes")
        
        if hex_view:
            print("\nHexadecimal view:")
            # Display payload in rows of 16 bytes
            offset = 0
            while offset < len(payload):
                # Get chunk of 16 bytes
                chunk = payload[offset:offset+16]
                # Convert to hex representation
                hex_line = ' '.join(f'{b:02x}' for b in chunk)
                # Add padding to align if less than 16 bytes
                hex_line = hex_line.ljust(47)
                
                # Convert to ASCII representation (printable chars only)
                ascii_line = ''.join(chr(b) if 32 <= b <= 126 else '.' for b in chunk)
                
                print(f"{offset:04x}: {hex_line} | {ascii_line}")
                offset += 16
        
        if text_view:
            print("\nText view:")
            try:
                text = payload.decode('utf-8', errors='replace')
                # Wrap text for better readability
                wrapped_text = textwrap.fill(text, width=80)
                print(wrapped_text)
            except Exception as e:
                print(f"Error decoding payload as text: {e}")
