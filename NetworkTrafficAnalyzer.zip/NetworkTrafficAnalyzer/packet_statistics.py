#!/usr/bin/env python3
"""
Packet Statistics Module - Provides statistical analysis of captured packets
"""
import logging
from collections import Counter, defaultdict
from scapy.all import IP, IPv6, TCP, UDP, ICMP, ARP
import pandas as pd
import matplotlib.pyplot as plt
from io import StringIO

# Setup logging
logger = logging.getLogger(__name__)


class PacketStatistics:
    """Class for statistical analysis of network packets"""
    
    def __init__(self):
        """Initialize the PacketStatistics class"""
        self.stats = {
            'total_packets': 0,
            'total_bytes': 0,
            'protocol_counts': Counter(),
            'ip_counts': defaultdict(Counter),
            'port_counts': defaultdict(Counter),
            'packet_sizes': [],
            'time_distribution': [],
        }
        self.df = None
    
    def generate_statistics(self, packets):
        """Generate statistics from captured packets
        
        Args:
            packets (list): List of packets to analyze
        """
        # Reset statistics
        self.__init__()
        
        if not packets:
            logger.warning("No packets available for statistics")
            return
        
        logger.debug(f"Generating statistics for {len(packets)} packets")
        
        # Basic stats
        self.stats['total_packets'] = len(packets)
        self.stats['total_bytes'] = sum(len(p) for p in packets)
        
        # Create list for DataFrame
        packet_data = []
        
        # Process each packet
        for packet in packets:
            time = packet.time
            size = len(packet)
            protocol = 'Other'
            src_ip = dst_ip = 'Unknown'
            src_port = dst_port = None
            
            # Store packet size
            self.stats['packet_sizes'].append(size)
            
            # Store packet time
            self.stats['time_distribution'].append(time)
            
            # Protocol statistics
            if IP in packet:
                protocol = 'IPv4'
                src_ip = packet[IP].src
                dst_ip = packet[IP].dst
                
                # Count source and destination IPs
                self.stats['ip_counts']['src'][src_ip] += 1
                self.stats['ip_counts']['dst'][dst_ip] += 1
                
                if TCP in packet:
                    protocol = 'TCP'
                    src_port = packet[TCP].sport
                    dst_port = packet[TCP].dport
                    
                    # Count source and destination ports
                    self.stats['port_counts']['src'][src_port] += 1
                    self.stats['port_counts']['dst'][dst_port] += 1
                
                elif UDP in packet:
                    protocol = 'UDP'
                    src_port = packet[UDP].sport
                    dst_port = packet[UDP].dport
                    
                    # Count source and destination ports
                    self.stats['port_counts']['src'][src_port] += 1
                    self.stats['port_counts']['dst'][dst_port] += 1
                
                elif ICMP in packet:
                    protocol = 'ICMP'
            
            elif IPv6 in packet:
                protocol = 'IPv6'
                src_ip = packet[IPv6].src
                dst_ip = packet[IPv6].dst
                
                # Count source and destination IPs
                self.stats['ip_counts']['src'][src_ip] += 1
                self.stats['ip_counts']['dst'][dst_ip] += 1
                
                if TCP in packet:
                    protocol = 'TCP (IPv6)'
                    src_port = packet[TCP].sport
                    dst_port = packet[TCP].dport
                    
                    # Count source and destination ports
                    self.stats['port_counts']['src'][src_port] += 1
                    self.stats['port_counts']['dst'][dst_port] += 1
                
                elif UDP in packet:
                    protocol = 'UDP (IPv6)'
                    src_port = packet[UDP].sport
                    dst_port = packet[UDP].dport
                    
                    # Count source and destination ports
                    self.stats['port_counts']['src'][src_port] += 1
                    self.stats['port_counts']['dst'][dst_port] += 1
            
            elif ARP in packet:
                protocol = 'ARP'
                src_ip = packet[ARP].psrc
                dst_ip = packet[ARP].pdst
                
                # Count source and destination IPs
                self.stats['ip_counts']['src'][src_ip] += 1
                self.stats['ip_counts']['dst'][dst_ip] += 1
            
            # Count protocol
            self.stats['protocol_counts'][protocol] += 1
            
            # Add to packet data list
            packet_data.append({
                'time': time,
                'size': size,
                'protocol': protocol,
                'src_ip': src_ip,
                'dst_ip': dst_ip,
                'src_port': src_port,
                'dst_port': dst_port
            })
        
        # Create DataFrame for more advanced analysis
        self.df = pd.DataFrame(packet_data)
        
        logger.debug("Statistics generation completed")
    
    def display_statistics(self):
        """Display the calculated statistics"""
        if self.stats['total_packets'] == 0:
            logger.warning("No statistics available to display")
            return
        
        print("\n" + "=" * 80)
        print("PACKET STATISTICS")
        print("=" * 80)
        
        # Basic statistics
        print(f"Total Packets: {self.stats['total_packets']}")
        print(f"Total Bytes: {self.stats['total_bytes']}")
        avg_packet_size = self.stats['total_bytes'] / self.stats['total_packets']
        print(f"Average Packet Size: {avg_packet_size:.2f} bytes")
        
        # Protocol distribution
        print("\nProtocol Distribution:")
        for protocol, count in self.stats['protocol_counts'].most_common():
            percentage = (count / self.stats['total_packets']) * 100
            print(f"  {protocol}: {count} packets ({percentage:.2f}%)")
        
        # Top source IPs
        print("\nTop Source IP Addresses:")
        for ip, count in self.stats['ip_counts']['src'].most_common(5):
            percentage = (count / self.stats['total_packets']) * 100
            print(f"  {ip}: {count} packets ({percentage:.2f}%)")
        
        # Top destination IPs
        print("\nTop Destination IP Addresses:")
        for ip, count in self.stats['ip_counts']['dst'].most_common(5):
            percentage = (count / self.stats['total_packets']) * 100
            print(f"  {ip}: {count} packets ({percentage:.2f}%)")
        
        # Top source ports
        if self.stats['port_counts']['src']:
            print("\nTop Source Ports:")
            for port, count in self.stats['port_counts']['src'].most_common(5):
                percentage = (count / sum(self.stats['port_counts']['src'].values())) * 100
                print(f"  Port {port}: {count} packets ({percentage:.2f}%)")
        
        # Top destination ports
        if self.stats['port_counts']['dst']:
            print("\nTop Destination Ports:")
            for port, count in self.stats['port_counts']['dst'].most_common(5):
                percentage = (count / sum(self.stats['port_counts']['dst'].values())) * 100
                print(f"  Port {port}: {count} packets ({percentage:.2f}%)")
        
        # Packet size statistics
        if self.stats['packet_sizes']:
            min_size = min(self.stats['packet_sizes'])
            max_size = max(self.stats['packet_sizes'])
            print(f"\nPacket Size Range: {min_size} - {max_size} bytes")
        
        print("=" * 80)
        
        # Try to display more advanced statistics using pandas
        try:
            if self.df is not None and not self.df.empty:
                print("\nAdvanced Statistics:")
                
                # Protocol summary
                protocol_summary = self.df['protocol'].value_counts()
                print("\nProtocol Summary:")
                print(protocol_summary)
                
                # Packet size statistics
                size_stats = self.df['size'].describe()
                print("\nPacket Size Statistics:")
                print(size_stats)
                
                # Check if matplotlib is available for plots
                try:
                    # Redirect plot to buffer (for terminal display)
                    plt.figure(figsize=(10, 6))
                    self.df['protocol'].value_counts().plot(kind='bar', title='Protocol Distribution')
                    plt.tight_layout()
                    
                    buffer = StringIO()
                    plt.savefig(buffer, format='svg')
                    plt.close()
                    
                    print("\nPlot would be displayed here in GUI environment.")
                    print("Use --save-plots option to save plots to files.")
                    
                except Exception as e:
                    logger.debug(f"Error creating plot: {e}")
                
        except Exception as e:
            logger.debug(f"Error generating advanced statistics: {e}")
    
    def save_plots(self, directory):
        """Save statistical plots to files
        
        Args:
            directory (str): Directory to save plots to
        """
        if self.df is None or self.df.empty:
            logger.warning("No data available for plotting")
            return
        
        try:
            import os
            os.makedirs(directory, exist_ok=True)
            
            # Protocol distribution
            plt.figure(figsize=(10, 6))
            self.df['protocol'].value_counts().plot(kind='bar', title='Protocol Distribution')
            plt.tight_layout()
            plt.savefig(os.path.join(directory, 'protocol_distribution.png'))
            plt.close()
            
            # Packet size histogram
            plt.figure(figsize=(10, 6))
            self.df['size'].plot(kind='hist', bins=20, title='Packet Size Distribution')
            plt.xlabel('Packet Size (bytes)')
            plt.ylabel('Frequency')
            plt.tight_layout()
            plt.savefig(os.path.join(directory, 'packet_size_distribution.png'))
            plt.close()
            
            # Traffic over time
            if 'time' in self.df.columns:
                plt.figure(figsize=(12, 6))
                # Convert timestamp to datetime
                self.df['datetime'] = pd.to_datetime(self.df['time'], unit='s')
                # Group by minute and count packets
                time_series = self.df.set_index('datetime').resample('1min').size()
                time_series.plot(title='Network Traffic Over Time')
                plt.xlabel('Time')
                plt.ylabel('Packets per Minute')
                plt.tight_layout()
                plt.savefig(os.path.join(directory, 'traffic_over_time.png'))
                plt.close()
            
            logger.info(f"Plots saved to directory: {directory}")
            
        except Exception as e:
            logger.error(f"Error saving plots: {e}")
    
    def export_to_csv(self, file_path):
        """Export statistics to a CSV file
        
        Args:
            file_path (str): Path to save the CSV file
        """
        if self.df is None or self.df.empty:
            logger.warning("No data available for export")
            return False
        
        try:
            self.df.to_csv(file_path, index=False)
            logger.info(f"Statistics exported to: {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting to CSV: {e}")
            return False
