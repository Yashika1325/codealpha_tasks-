#!/usr/bin/env python3
"""
Network Sniffer Module - Main entry point for the network sniffer application
"""
import argparse
import logging
import os
import sys
from datetime import datetime

from packet_analyzer import PacketAnalyzer
from packet_capture import PacketCapture
from packet_filter import PacketFilter
from packet_statistics import PacketStatistics

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class NetworkSniffer:
    """Network Sniffer main class"""
    
    def __init__(self):
        """Initialize the Network Sniffer"""
        self.packet_capture = PacketCapture()
        self.packet_filter = PacketFilter()
        self.packet_analyzer = PacketAnalyzer()
        self.packet_statistics = PacketStatistics()
        self.packets = []
        self.filtered_packets = []
        
    def parse_arguments(self):
        """Parse command line arguments"""
        parser = argparse.ArgumentParser(description='Python Network Sniffer')
        
        parser.add_argument('-i', '--interface', 
                            help='Network interface to capture packets from')
        parser.add_argument('-c', '--count', type=int, default=0,
                            help='Number of packets to capture (0 for infinite)')
        parser.add_argument('-t', '--timeout', type=int, default=None,
                            help='Timeout in seconds for packet capture')
        parser.add_argument('-f', '--filter', 
                            help='BPF filter string (e.g., "tcp port 80")')
        parser.add_argument('-p', '--protocol', 
                            choices=['tcp', 'udp', 'icmp', 'all'],
                            default='all', help='Protocol filter')
        parser.add_argument('-w', '--write', 
                            help='Write packets to pcap file')
        parser.add_argument('-r', '--read',
                            help='Read packets from pcap file')
        parser.add_argument('-v', '--verbose', action='store_true',
                            help='Enable verbose output')
        parser.add_argument('-s', '--stats', action='store_true',
                            help='Show packet statistics')
        
        return parser.parse_args()
    
    def run(self):
        """Run the network sniffer"""
        args = self.parse_arguments()
        
        # Set logging level based on verbose flag
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)
            logger.debug("Verbose mode enabled")
        
        try:
            if args.read:
                # Read packets from pcap file
                logger.info(f"Reading packets from file: {args.read}")
                self.packets = self.packet_capture.read_pcap(args.read)
                logger.info(f"Read {len(self.packets)} packets from file")
            else:
                # Capture packets from network interface
                interface = args.interface
                if not interface:
                    # If no interface is provided, list available interfaces
                    interfaces = self.packet_capture.get_interfaces()
                    logger.info("Available interfaces:")
                    for i, iface in enumerate(interfaces, 1):
                        logger.info(f"{i}. {iface}")
                    selection = input("Select interface number: ")
                    try:
                        interface = interfaces[int(selection) - 1]
                    except (ValueError, IndexError):
                        logger.error("Invalid selection. Exiting.")
                        return
                
                logger.info(f"Starting packet capture on interface: {interface}")
                # Prepare BPF filter string based on protocol and custom filter
                filter_string = ""
                if args.protocol != 'all':
                    filter_string = args.protocol
                if args.filter:
                    if filter_string:
                        filter_string += f" and ({args.filter})"
                    else:
                        filter_string = args.filter
                
                if filter_string:
                    logger.info(f"Using filter: {filter_string}")
                
                # Capture packets
                self.packets = self.packet_capture.capture_packets(
                    interface=interface, 
                    count=args.count,
                    timeout=args.timeout,
                    filter_string=filter_string
                )
                logger.info(f"Captured {len(self.packets)} packets")
            
            # Apply protocol filter if specified
            if args.protocol != 'all':
                logger.info(f"Filtering packets by protocol: {args.protocol}")
                self.filtered_packets = self.packet_filter.filter_by_protocol(
                    self.packets, args.protocol
                )
            else:
                self.filtered_packets = self.packets
            
            # Display packet information
            self.packet_analyzer.display_packet_summary(self.filtered_packets)
            
            # Save packets to file if specified
            if args.write:
                output_file = args.write
                if not output_file.endswith('.pcap'):
                    output_file += '.pcap'
                logger.info(f"Writing packets to file: {output_file}")
                self.packet_capture.write_pcap(self.filtered_packets, output_file)
                logger.info(f"Wrote {len(self.filtered_packets)} packets to {output_file}")
            
            # Show statistics if requested
            if args.stats:
                logger.info("Generating packet statistics...")
                self.packet_statistics.generate_statistics(self.filtered_packets)
                self.packet_statistics.display_statistics()
            
        except KeyboardInterrupt:
            logger.info("Capture interrupted by user")
        except PermissionError:
            logger.error("Permission denied. Try running with elevated privileges (sudo)")
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            if args.verbose:
                import traceback
                logger.debug(traceback.format_exc())
        
        logger.info("Network sniffer completed")


if __name__ == "__main__":
    # Check for root privileges if not running on Windows
    if os.name != 'nt' and os.geteuid() != 0:
        logger.warning("Warning: Network sniffing typically requires root privileges.")
        logger.warning("Some features may not work properly without sudo/root access.")
    
    sniffer = NetworkSniffer()
    sniffer.run()
