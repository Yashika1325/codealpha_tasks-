// Network Sniffer Web Interface JavaScript

// Global variables
let captureStartTime = null;
let captureTimer = null;
let selectedPacketId = null;
let protocolChart = null;

// Initialize the app when document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    feather.replace();
    
    // Setup navigation
    setupNavigation();
    
    // Load available interfaces
    loadInterfaces();
    
    // Setup event listeners
    setupEventListeners();
});

// Setup navigation between sections
function setupNavigation() {
    const sections = ['capture', 'packets', 'statistics', 'host-info'];
    
    sections.forEach(section => {
        const navLink = document.getElementById(`${section}-nav`);
        
        navLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Hide all sections
            sections.forEach(s => {
                document.getElementById(`${s}-section`).style.display = 'none';
                document.getElementById(`${s}-nav`).classList.remove('active');
            });
            
            // Show selected section
            document.getElementById(`${section}-section`).style.display = 'block';
            this.classList.add('active');
            
            // Special handling for sections
            if (section === 'statistics') {
                loadStatistics();
            } else if (section === 'host-info') {
                loadHostInfo();
            } else if (section === 'packets') {
                refreshPacketsList();
            }
        });
    });
}

// Setup all event listeners
function setupEventListeners() {
    // Capture form submission
    document.getElementById('capture-form').addEventListener('submit', function(e) {
        e.preventDefault();
        startCapture();
    });
    
    // Stop capture button
    document.getElementById('stop-capture').addEventListener('click', stopCapture);
    
    // Filter type selection
    document.getElementById('filter-type').addEventListener('change', function() {
        toggleFilterOptions(this.value);
    });
    
    // Filter form submission
    document.getElementById('filter-form').addEventListener('submit', function(e) {
        e.preventDefault();
        applyFilter();
    });
}

// Load available network interfaces
function loadInterfaces() {
    fetch('/interfaces')
        .then(response => response.json())
        .then(interfaces => {
            const select = document.getElementById('interface-select');
            
            // Clear existing options
            while (select.options.length > 1) {
                select.remove(1);
            }
            
            // Add new options
            interfaces.forEach(iface => {
                const option = document.createElement('option');
                option.value = iface;
                option.textContent = iface;
                select.appendChild(option);
            });
        })
        .catch(error => {
            showMessage(`Error loading interfaces: ${error}`, 'danger');
        });
}

// Start packet capture
function startCapture() {
    const interface = document.getElementById('interface-select').value;
    const count = document.getElementById('packet-count').value;
    const timeout = document.getElementById('timeout').value;
    const filterString = document.getElementById('filter-string').value;
    
    if (!interface) {
        showMessage('Please select a network interface', 'warning');
        return;
    }
    
    // Create form data
    const formData = new FormData();
    formData.append('interface', interface);
    formData.append('count', count);
    if (timeout) formData.append('timeout', timeout);
    if (filterString) formData.append('filter', filterString);
    
    // Send request to start capture
    fetch('/start_capture', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                showMessage(data.message, 'success');
                
                // Update UI for active capture
                document.getElementById('capture-status').textContent = 'Active';
                document.getElementById('capture-status').className = 'badge bg-success';
                document.getElementById('selected-interface').textContent = interface;
                
                // Update buttons
                document.getElementById('start-capture').disabled = true;
                document.getElementById('stop-capture').disabled = false;
                document.getElementById('apply-filter').disabled = true;
                
                // Start the capture timer
                captureStartTime = new Date();
                if (captureTimer) clearInterval(captureTimer);
                captureTimer = setInterval(updateCaptureTime, 1000);
                
                // Start polling for packets
                pollPacketCount();
            } else {
                showMessage(data.message, 'danger');
            }
        })
        .catch(error => {
            showMessage(`Error starting capture: ${error}`, 'danger');
        });
}

// Stop packet capture
function stopCapture() {
    fetch('/stop_capture')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                showMessage(data.message, 'success');
                
                // Update UI for stopped capture
                document.getElementById('capture-status').textContent = 'Stopped';
                document.getElementById('capture-status').className = 'badge bg-secondary';
                document.getElementById('packets-captured').textContent = data.packet_count;
                
                // Update buttons
                document.getElementById('start-capture').disabled = false;
                document.getElementById('stop-capture').disabled = true;
                document.getElementById('apply-filter').disabled = false;
                
                // Stop the capture timer
                if (captureTimer) {
                    clearInterval(captureTimer);
                    captureTimer = null;
                }
                
                // Refresh the packets list
                refreshPacketsList();
            } else {
                showMessage(data.message, 'danger');
            }
        })
        .catch(error => {
            showMessage(`Error stopping capture: ${error}`, 'danger');
        });
}

// Poll for packet count during capture
function pollPacketCount() {
    if (document.getElementById('capture-status').textContent !== 'Active') {
        return;
    }
    
    fetch('/packets')
        .then(response => response.json())
        .then(packets => {
            document.getElementById('packets-captured').textContent = packets.length;
            
            // Continue polling if still active
            if (document.getElementById('capture-status').textContent === 'Active') {
                setTimeout(pollPacketCount, 1000);
            }
        })
        .catch(error => {
            console.error('Error polling packet count:', error);
            // Continue anyway
            if (document.getElementById('capture-status').textContent === 'Active') {
                setTimeout(pollPacketCount, 1000);
            }
        });
}

// Update the capture duration timer
function updateCaptureTime() {
    if (!captureStartTime) return;
    
    const now = new Date();
    const diff = now - captureStartTime;
    
    // Format as HH:MM:SS
    const hours = Math.floor(diff / 3600000).toString().padStart(2, '0');
    const minutes = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
    const seconds = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
    
    document.getElementById('capture-duration').textContent = `${hours}:${minutes}:${seconds}`;
}

// Toggle filter options based on selected filter type
function toggleFilterOptions(filterType) {
    const filterOptions = document.querySelectorAll('.filter-option');
    
    // Hide all filter options
    filterOptions.forEach(option => {
        option.style.display = 'none';
    });
    
    // Show selected filter option
    document.getElementById(`${filterType}-filter`).style.display = 'block';
}

// Apply filter to captured packets
function applyFilter() {
    const filterType = document.getElementById('filter-type').value;
    let formData = new FormData();
    
    formData.append('type', filterType);
    
    // Add filter-specific values
    if (filterType === 'protocol') {
        formData.append('value', document.getElementById('protocol-value').value);
    } else if (filterType === 'ip') {
        formData.append('value', document.getElementById('ip-value').value);
    } else if (filterType === 'port') {
        formData.append('value', document.getElementById('port-value').value);
        formData.append('port_type', document.getElementById('port-type').value);
    } else if (filterType === 'length') {
        formData.append('min_length', document.getElementById('min-length').value);
        formData.append('max_length', document.getElementById('max-length').value);
    }
    
    // Send request to apply filter
    fetch('/filter', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                showMessage(data.message, 'success');
                document.getElementById('packets-captured').textContent = data.packet_count;
                
                // Refresh the packets list
                refreshPacketsList();
            } else {
                showMessage(data.message, 'danger');
            }
        })
        .catch(error => {
            showMessage(`Error applying filter: ${error}`, 'danger');
        });
}

// Refresh the list of captured packets
function refreshPacketsList() {
    fetch('/packets')
        .then(response => response.json())
        .then(packets => {
            const tableBody = document.getElementById('packets-table-body');
            const packetCountBadge = document.getElementById('packet-count-badge');
            
            // Update packet count badge
            packetCountBadge.textContent = `${packets.length} Packets`;
            
            // Clear existing rows
            tableBody.innerHTML = '';
            
            // Add packet data
            packets.forEach(packet => {
                const row = document.createElement('tr');
                row.dataset.packetId = packet.id;
                
                row.innerHTML = `
                    <td>${packet.id}</td>
                    <td>${packet.time}</td>
                    <td>${packet.protocol}</td>
                    <td>${packet.source}</td>
                    <td>${packet.destination}</td>
                    <td>${packet.length}</td>
                    <td>${packet.info}</td>
                `;
                
                row.addEventListener('click', function() {
                    const packetId = this.dataset.packetId;
                    selectPacket(packetId);
                });
                
                tableBody.appendChild(row);
            });
        })
        .catch(error => {
            showMessage(`Error loading packets: ${error}`, 'danger');
        });
}

// Select a packet to show details
function selectPacket(packetId) {
    selectedPacketId = packetId;
    
    // Update selected row styling
    const rows = document.querySelectorAll('#packets-table-body tr');
    rows.forEach(row => {
        row.classList.remove('selected-packet');
        if (row.dataset.packetId === packetId) {
            row.classList.add('selected-packet');
        }
    });
    
    // Show the packet details card
    document.getElementById('packet-details-card').style.display = 'block';
    
    // Load packet details
    fetch(`/packet/${packetId}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'error') {
                showMessage(data.message, 'danger');
                return;
            }
            
            // Populate details tab
            const detailsDiv = document.getElementById('packet-details');
            
            let detailsHtml = '<dl class="row">';
            
            // Add all available details
            const details = data.details;
            detailsHtml += `<dt class="col-sm-3">Time</dt><dd class="col-sm-9">${details.time}</dd>`;
            detailsHtml += `<dt class="col-sm-3">Length</dt><dd class="col-sm-9">${details.length} bytes</dd>`;
            detailsHtml += `<dt class="col-sm-3">Protocol</dt><dd class="col-sm-9">${details.protocol}</dd>`;
            
            if (details.src_ip) {
                detailsHtml += `<dt class="col-sm-3">Source IP</dt><dd class="col-sm-9">${details.src_ip}</dd>`;
            }
            if (details.dst_ip) {
                detailsHtml += `<dt class="col-sm-3">Destination IP</dt><dd class="col-sm-9">${details.dst_ip}</dd>`;
            }
            if (details.src_port) {
                detailsHtml += `<dt class="col-sm-3">Source Port</dt><dd class="col-sm-9">${details.src_port}</dd>`;
            }
            if (details.dst_port) {
                detailsHtml += `<dt class="col-sm-3">Destination Port</dt><dd class="col-sm-9">${details.dst_port}</dd>`;
            }
            if (details.transport) {
                detailsHtml += `<dt class="col-sm-3">Transport</dt><dd class="col-sm-9">${details.transport}</dd>`;
            }
            if (details.ttl) {
                detailsHtml += `<dt class="col-sm-3">TTL</dt><dd class="col-sm-9">${details.ttl}</dd>`;
            }
            if (details.flags) {
                detailsHtml += `<dt class="col-sm-3">TCP Flags</dt><dd class="col-sm-9">${details.flags}</dd>`;
            }
            if (details.app_protocol) {
                detailsHtml += `<dt class="col-sm-3">Application Protocol</dt><dd class="col-sm-9">${details.app_protocol}</dd>`;
            }
            
            detailsHtml += `<dt class="col-sm-3">Summary</dt><dd class="col-sm-9">${data.summary}</dd>`;
            detailsHtml += '</dl>';
            
            detailsDiv.innerHTML = detailsHtml;
            
            // Populate hex tab
            const hexPre = document.getElementById('packet-hex');
            hexPre.textContent = data.hexdump.join('\n');
            
            // Populate payload tab
            const payloadHexPre = document.getElementById('payload-hex');
            const payloadTextPre = document.getElementById('payload-text');
            
            if (data.payload_hex) {
                payloadHexPre.textContent = data.payload_hex;
                payloadHexPre.parentElement.style.display = 'block';
            } else {
                payloadHexPre.textContent = 'No payload data available.';
                payloadHexPre.parentElement.style.display = 'none';
            }
            
            if (data.payload_text) {
                payloadTextPre.textContent = data.payload_text;
                payloadTextPre.parentElement.style.display = 'block';
            } else {
                payloadTextPre.textContent = 'No payload text available.';
                payloadTextPre.parentElement.style.display = 'none';
            }
        })
        .catch(error => {
            showMessage(`Error loading packet details: ${error}`, 'danger');
        });
}

// Load statistics data
function loadStatistics() {
    fetch('/statistics')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'error') {
                showMessage(data.message, 'warning');
                return;
            }
            
            // Update basic stats
            document.getElementById('stat-total-packets').textContent = data.total_packets;
            document.getElementById('stat-total-bytes').textContent = data.total_bytes;
            document.getElementById('stat-avg-size').textContent = data.avg_packet_size.toFixed(2) + ' bytes';
            
            // Generate protocol chart
            createProtocolChart(data.protocol_counts);
            
            // Update top source IPs
            updateTopList('top-src-ips', data.top_src_ips);
            
            // Update top destination IPs
            updateTopList('top-dst-ips', data.top_dst_ips);
            
            // Update top source ports
            updateTopList('top-src-ports', data.top_src_ports);
            
            // Update top destination ports
            updateTopList('top-dst-ports', data.top_dst_ports);
        })
        .catch(error => {
            showMessage(`Error loading statistics: ${error}`, 'danger');
        });
}

// Create protocol distribution chart
function createProtocolChart(protocolCounts) {
    const ctx = document.getElementById('protocol-chart').getContext('2d');
    
    // Destroy previous chart if it exists
    if (protocolChart) {
        protocolChart.destroy();
    }
    
    // Prepare data for chart
    const labels = Object.keys(protocolCounts);
    const data = Object.values(protocolCounts);
    
    // Generate colors
    const colors = labels.map((_, i) => {
        // Generate colors based on index
        const hue = (i * 137) % 360; // Use golden ratio to spread colors
        return `hsl(${hue}, 70%, 60%)`;
    });
    
    // Create chart
    protocolChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Update a top-list with data
function updateTopList(elementId, dataObject) {
    const listElement = document.getElementById(elementId);
    
    // Clear existing items
    listElement.innerHTML = '';
    
    // If no data, show message
    if (Object.keys(dataObject).length === 0) {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = 'No data available';
        listElement.appendChild(li);
        return;
    }
    
    // Calculate total for percentages
    const total = Object.values(dataObject).reduce((a, b) => a + b, 0);
    
    // Add items to list
    Object.entries(dataObject).forEach(([key, value]) => {
        const percentage = Math.round((value / total) * 100);
        
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between align-items-center';
        
        // Create main text
        const textSpan = document.createElement('span');
        textSpan.textContent = key;
        li.appendChild(textSpan);
        
        // Create badge
        const badge = document.createElement('span');
        badge.className = 'badge bg-primary rounded-pill';
        badge.textContent = `${value} (${percentage}%)`;
        li.appendChild(badge);
        
        listElement.appendChild(li);
    });
}

// Load host information
function loadHostInfo() {
    fetch('/hostinfo')
        .then(response => response.json())
        .then(data => {
            document.getElementById('host-hostname').textContent = data.hostname || 'Unknown';
            document.getElementById('host-ip').textContent = data.ip || 'Unknown';
            
            // Update interfaces table
            const interfacesTable = document.getElementById('host-interfaces');
            interfacesTable.innerHTML = '';
            
            if (data.interfaces && Object.keys(data.interfaces).length > 0) {
                for (const [iface, ip] of Object.entries(data.interfaces)) {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${iface}</td>
                        <td>${ip}</td>
                    `;
                    interfacesTable.appendChild(row);
                }
            } else {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td colspan="2" class="text-center">No network interfaces found</td>
                `;
                interfacesTable.appendChild(row);
            }
        })
        .catch(error => {
            showMessage(`Error loading host information: ${error}`, 'danger');
        });
}

// Display a message to the user
function showMessage(message, type = 'info') {
    const alert = document.getElementById('status-message');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    alert.style.display = 'block';
    
    // Hide after 5 seconds
    setTimeout(() => {
        alert.style.display = 'none';
    }, 5000);
}