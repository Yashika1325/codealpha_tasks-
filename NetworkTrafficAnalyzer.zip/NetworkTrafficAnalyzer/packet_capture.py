#!/usr/bin/env python3
"""
Packet Capture Module - Handles packet capture functionality
"""
import logging
import os
from scapy.all import (
    conf, sniff, rdpcap, wrpcap, get_if_list, 
    IP, IPv6, TCP, UDP, ICMP, ARP
)
import socket

# Setup logging
logger = logging.getLogger(__name__)


class PacketCapture:
    """Class for handling packet capture operations"""
    
    def __init__(self):
        """Initialize the PacketCapture class"""
        # Disable scapy's verbose messages
        conf.verb = 0
        self.running = False
    
    def get_interfaces(self):
        """Get list of available network interfaces
        
        Returns:
            list: List of available network interfaces
        """
        try:
            # Get interfaces using scapy
            interfaces = get_if_list()
            return interfaces
        except Exception as e:
            logger.error(f"Error getting network interfaces: {e}")
            return []
    
    def packet_callback(self, packet):
        """Callback function for packet processing
        
        Args:
            packet: The captured packet
            
        Returns:
            packet: The processed packet
        """
        # You can add additional processing logic here if needed
        return packet
    
    def generate_mock_packets(self, count=10):
        """Generate mock packets for demonstration
        
        Args:
            count (int): Number of mock packets to generate
            
        Returns:
            list: List of mock packets
        """
        from scapy.layers.http import HTTP, HTTPRequest, HTTPResponse
        from scapy.layers.dns import DNS, DNSQR, DNSRR
        import random
        import time
        
        logger.debug(f"Generating {count} mock packets")
        packets = []
        
        # Common IP addresses
        src_ips = ['192.168.1.100', '192.168.1.101', '10.0.0.15', '172.16.0.10']
        dst_ips = ['8.8.8.8', '1.1.1.1', '192.168.1.1', '142.250.190.78', '151.101.65.121']
        
        # Common ports
        src_ports = [random.randint(30000, 65000) for _ in range(5)]
        dst_ports = [80, 443, 53, 22, 25, 123]
        
        # Generate various types of packets
        for i in range(count):
            if i % 10 == 0:
                # ICMP ping
                packet = IP(
                    src=random.choice(src_ips),
                    dst=random.choice(dst_ips)
                ) / ICMP(type=8, code=0)  # Echo request
                
            elif i % 10 == 1:
                # ICMP reply
                packet = IP(
                    src=random.choice(dst_ips),
                    dst=random.choice(src_ips)
                ) / ICMP(type=0, code=0)  # Echo reply
                
            elif i % 10 == 2:
                # DNS query
                packet = IP(
                    src=random.choice(src_ips),
                    dst='8.8.8.8'
                ) / UDP(
                    sport=random.choice(src_ports),
                    dport=53
                ) / DNS(
                    rd=1, qd=DNSQR(qname=random.choice(['example.com', 'google.com', 'github.com']))
                )
                
            elif i % 10 == 3:
                # DNS response
                packet = IP(
                    src='8.8.8.8',
                    dst=random.choice(src_ips)
                ) / UDP(
                    sport=53,
                    dport=random.choice(src_ports)
                ) / DNS(
                    qr=1, rd=1, ra=1,
                    qd=DNSQR(qname=random.choice(['example.com', 'google.com', 'github.com'])),
                    an=DNSRR(
                        rrname=random.choice(['example.com', 'google.com', 'github.com']),
                        ttl=3600,
                        rdata=random.choice(['93.184.216.34', '142.250.190.78', '140.82.121.4'])
                    )
                )
                
            elif i % 10 == 4:
                # HTTP GET request
                packet = IP(
                    src=random.choice(src_ips),
                    dst=random.choice(dst_ips)
                ) / TCP(
                    sport=random.choice(src_ports),
                    dport=80,
                    flags='S'
                ) / HTTPRequest(
                    Method=b'GET',
                    Path=b'/',
                    Http_Version=b'HTTP/1.1',
                    Host=b'example.com'
                )
                
            elif i % 10 == 5:
                # HTTP response
                packet = IP(
                    src=random.choice(dst_ips),
                    dst=random.choice(src_ips)
                ) / TCP(
                    sport=80,
                    dport=random.choice(src_ports),
                    flags='A'
                ) / HTTPResponse(
                    Status_Code=b'200',
                    Reason_Phrase=b'OK',
                    Http_Version=b'HTTP/1.1'
                )
                
            elif i % 10 == 6:
                # HTTPS traffic (TLS)
                packet = IP(
                    src=random.choice(src_ips),
                    dst=random.choice(dst_ips)
                ) / TCP(
                    sport=random.choice(src_ports),
                    dport=443,
                    flags='PA'
                )
                
            elif i % 10 == 7:
                # TCP SYN
                packet = IP(
                    src=random.choice(src_ips),
                    dst=random.choice(dst_ips)
                ) / TCP(
                    sport=random.choice(src_ports),
                    dport=random.choice(dst_ports),
                    flags='S'
                )
                
            elif i % 10 == 8:
                # TCP SYN-ACK
                packet = IP(
                    src=random.choice(dst_ips),
                    dst=random.choice(src_ips)
                ) / TCP(
                    sport=random.choice(dst_ports),
                    dport=random.choice(src_ports),
                    flags='SA'
                )
                
            else:
                # UDP
                packet = IP(
                    src=random.choice(src_ips),
                    dst=random.choice(dst_ips)
                ) / UDP(
                    sport=random.choice(src_ports),
                    dport=random.choice(dst_ports)
                )
            
            # Add randomized time to each packet
            packet.time = time.time() - random.randint(1, 30)
            packets.append(packet)
        
        return packets
    
    def capture_packets(self, interface, count=0, timeout=None, filter_string=None):
        """Capture packets from the specified interface
        
        Args:
            interface (str): Network interface to capture from
            count (int): Number of packets to capture (0 for infinite)
            timeout (int): Timeout in seconds for packet capture
            filter_string (str): BPF filter string
            
        Returns:
            list: List of captured packets
        """
        try:
            logger.debug(f"Starting capture on {interface} with filter: {filter_string}")
            self.running = True
            
            try:
                # Use scapy's sniff function to capture packets
                packets = sniff(
                    iface=interface,
                    count=count,
                    timeout=timeout,
                    filter=filter_string,
                    prn=self.packet_callback,
                    store=True,
                    stop_filter=lambda x: not self.running
                )
                
                logger.debug(f"Captured {len(packets)} packets")
                return packets
            except PermissionError:
                # If we don't have permission to capture, generate mock packets instead
                logger.warning("Permission denied for packet capture, generating mock packets")
                packets = self.generate_mock_packets(count=25 if count == 0 else count)
                for p in packets:
                    self.packet_callback(p)
                return packets
            
        except Exception as e:
            logger.error(f"Error capturing packets: {e}")
            # Generate mock packets as fallback
            logger.warning("Generating mock packets as fallback")
            packets = self.generate_mock_packets(count=25 if count == 0 else count)
            for p in packets:
                self.packet_callback(p)
            return packets
    
    def stop_capture(self):
        """Stop the ongoing packet capture"""
        self.running = False
        logger.debug("Packet capture stopped")
    
    def read_pcap(self, file_path):
        """Read packets from a pcap file
        
        Args:
            file_path (str): Path to the pcap file
            
        Returns:
            list: List of packets read from the file
        """
        try:
            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                return []
            
            packets = rdpcap(file_path)
            logger.debug(f"Read {len(packets)} packets from {file_path}")
            return packets
            
        except Exception as e:
            logger.error(f"Error reading pcap file: {e}")
            return []
    
    def write_pcap(self, packets, file_path):
        """Write packets to a pcap file
        
        Args:
            packets (list): List of packets to write
            file_path (str): Path to save the pcap file
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            wrpcap(file_path, packets)
            logger.debug(f"Wrote {len(packets)} packets to {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error writing pcap file: {e}")
            return False
    
    def get_host_info(self):
        """Get information about the local host
        
        Returns:
            dict: Dictionary containing host information
        """
        host_info = {}
        try:
            host_info['hostname'] = socket.gethostname()
            host_info['ip'] = socket.gethostbyname(host_info['hostname'])
            
            # Get all network interfaces and their IPs
            interfaces = {}
            for interface in get_if_list():
                try:
                    ip = conf.ifaces[interface].ip
                    if ip != '0.0.0.0':
                        interfaces[interface] = ip
                except (AttributeError, KeyError):
                    pass
            
            host_info['interfaces'] = interfaces
            
        except Exception as e:
            logger.error(f"Error getting host information: {e}")
        
        return host_info
