#!/usr/bin/env python3
"""
Packet Filter Module - Provides filtering capabilities for network packets
"""
import logging
from scapy.all import IP, IPv6, TCP, UDP, ICMP, ARP

# Setup logging
logger = logging.getLogger(__name__)


class PacketFilter:
    """Class for packet filtering operations"""
    
    def __init__(self):
        """Initialize the PacketFilter class"""
        pass
    
    def filter_by_protocol(self, packets, protocol):
        """Filter packets by protocol type
        
        Args:
            packets (list): List of packets to filter
            protocol (str): Protocol to filter by ('tcp', 'udp', 'icmp')
            
        Returns:
            list: Filtered packet list
        """
        filtered_packets = []
        protocol = protocol.lower()
        
        logger.debug(f"Filtering {len(packets)} packets by protocol: {protocol}")
        
        for packet in packets:
            if protocol == 'tcp' and TCP in packet:
                filtered_packets.append(packet)
            elif protocol == 'udp' and UDP in packet:
                filtered_packets.append(packet)
            elif protocol == 'icmp' and ICMP in packet:
                filtered_packets.append(packet)
        
        logger.debug(f"Filtered down to {len(filtered_packets)} packets")
        return filtered_packets
    
    def filter_by_ip(self, packets, ip_address):
        """Filter packets by IP address (source or destination)
        
        Args:
            packets (list): List of packets to filter
            ip_address (str): IP address to filter by
            
        Returns:
            list: Filtered packet list
        """
        filtered_packets = []
        
        logger.debug(f"Filtering {len(packets)} packets by IP: {ip_address}")
        
        for packet in packets:
            if IP in packet:
                if packet[IP].src == ip_address or packet[IP].dst == ip_address:
                    filtered_packets.append(packet)
            elif IPv6 in packet:
                if packet[IPv6].src == ip_address or packet[IPv6].dst == ip_address:
                    filtered_packets.append(packet)
        
        logger.debug(f"Filtered down to {len(filtered_packets)} packets")
        return filtered_packets
    
    def filter_by_port(self, packets, port, port_type=None):
        """Filter packets by port number (source, destination, or both)
        
        Args:
            packets (list): List of packets to filter
            port (int): Port number to filter by
            port_type (str): Type of port ('src', 'dst', or None for both)
            
        Returns:
            list: Filtered packet list
        """
        filtered_packets = []
        
        logger.debug(f"Filtering {len(packets)} packets by port: {port} (type: {port_type})")
        
        for packet in packets:
            if TCP in packet:
                if port_type == 'src' and packet[TCP].sport == port:
                    filtered_packets.append(packet)
                elif port_type == 'dst' and packet[TCP].dport == port:
                    filtered_packets.append(packet)
                elif port_type is None and (packet[TCP].sport == port or packet[TCP].dport == port):
                    filtered_packets.append(packet)
            elif UDP in packet:
                if port_type == 'src' and packet[UDP].sport == port:
                    filtered_packets.append(packet)
                elif port_type == 'dst' and packet[UDP].dport == port:
                    filtered_packets.append(packet)
                elif port_type is None and (packet[UDP].sport == port or packet[UDP].dport == port):
                    filtered_packets.append(packet)
        
        logger.debug(f"Filtered down to {len(filtered_packets)} packets")
        return filtered_packets
    
    def filter_by_length(self, packets, min_length=None, max_length=None):
        """Filter packets by length
        
        Args:
            packets (list): List of packets to filter
            min_length (int): Minimum packet length (None for no minimum)
            max_length (int): Maximum packet length (None for no maximum)
            
        Returns:
            list: Filtered packet list
        """
        filtered_packets = []
        
        logger.debug(f"Filtering {len(packets)} packets by length: min={min_length}, max={max_length}")
        
        for packet in packets:
            length = len(packet)
            if min_length is not None and length < min_length:
                continue
            if max_length is not None and length > max_length:
                continue
            filtered_packets.append(packet)
        
        logger.debug(f"Filtered down to {len(filtered_packets)} packets")
        return filtered_packets
    
    def apply_custom_filter(self, packets, filter_func):
        """Apply a custom filter function to packets
        
        Args:
            packets (list): List of packets to filter
            filter_func (function): Custom filter function that takes a packet as input
                                    and returns True to keep it or False to filter it out
            
        Returns:
            list: Filtered packet list
        """
        filtered_packets = []
        
        logger.debug(f"Applying custom filter to {len(packets)} packets")
        
        for packet in packets:
            if filter_func(packet):
                filtered_packets.append(packet)
        
        logger.debug(f"Filtered down to {len(filtered_packets)} packets")
        return filtered_packets
