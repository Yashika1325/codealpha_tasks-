import os
import logging
from flask import Flask, render_template, jsonify, request, flash, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
import threading
import time

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Define SQLAlchemy base
class Base(DeclarativeBase):
    pass

# Initialize Flask and SQLAlchemy
db = SQLAlchemy(model_class=Base)
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-for-development")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure database
# Use PostgreSQL database if DATABASE_URL is provided, otherwise fallback to SQLite
database_url = os.environ.get("DATABASE_URL")
if database_url and database_url.startswith("postgres://"):
    # Fix for SQLAlchemy 1.4+ which requires postgresql:// instead of postgres://
    database_url = database_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = database_url or "sqlite:///ids.db"
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

# Import after initialization to avoid circular imports
from models import Rule, Alert, TrafficSnapshot
from packet_analyzer import PacketAnalyzer
from rule_engine import RuleEngine
from alert_manager import AlertManager

# Initialize components
packet_analyzer = None
rule_engine = None
alert_manager = None
capture_thread = None
capture_running = False

def initialize_components():
    global packet_analyzer, rule_engine, alert_manager
    with app.app_context():
        # Create all database tables
        db.create_all()
        
        # Load rules from database
        rules = Rule.query.all()
        if not rules:
            # Create default rules if none exist
            default_rules = [
                Rule(name="ICMP Flood", description="Detects ICMP flood attacks", 
                     rule_type="threshold", protocol="icmp", threshold=10, 
                     time_window=5, enabled=True),
                Rule(name="Port Scan", description="Detects port scanning activity", 
                     rule_type="signature", protocol="tcp", 
                     pattern="multiple ports accessed in short timeframe", enabled=True),
                Rule(name="SSH Brute Force", description="Detects SSH brute force attempts", 
                     rule_type="threshold", protocol="tcp", port=22, threshold=5, 
                     time_window=60, enabled=True),
                Rule(name="DNS Amplification", description="Detects DNS amplification attacks", 
                     rule_type="anomaly", protocol="udp", port=53, enabled=True),
                Rule(name="HTTP Flood", description="Detects HTTP flood attacks", 
                     rule_type="threshold", protocol="tcp", port=80, threshold=100, 
                     time_window=10, enabled=True)
            ]
            for rule in default_rules:
                db.session.add(rule)
            db.session.commit()
            rules = default_rules
        
        # Initialize components
        rule_engine = RuleEngine(rules)
        alert_manager = AlertManager()
        packet_analyzer = PacketAnalyzer(rule_engine, alert_manager)

def capture_packets():
    global capture_running
    while capture_running:
        try:
            # Use a fresh db session for each capture cycle
            with app.app_context():
                # Capture packets and process them
                packet_analyzer.capture_packets(duration=5)
                
                # Save traffic snapshot
                traffic_data = packet_analyzer.get_traffic_stats()
                snapshot = TrafficSnapshot(
                    timestamp=int(time.time()),
                    total_packets=traffic_data.get('total_packets', 0),
                    tcp_packets=traffic_data.get('tcp_packets', 0),
                    udp_packets=traffic_data.get('udp_packets', 0),
                    icmp_packets=traffic_data.get('icmp_packets', 0),
                    other_packets=traffic_data.get('other_packets', 0)
                )
                db.session.add(snapshot)
                db.session.commit()
        except Exception as e:
            logger.error(f"Error in packet capture: {str(e)}")
            # Rollback any failed transaction
            with app.app_context():
                db.session.rollback()
            time.sleep(5)  # Wait before retrying

def start_capture():
    global capture_thread, capture_running
    if not capture_running:
        capture_running = True
        capture_thread = threading.Thread(target=capture_packets)
        capture_thread.daemon = True
        capture_thread.start()
        logger.info("Packet capture started")

def stop_capture():
    global capture_running
    capture_running = False
    logger.info("Packet capture stopped")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/traffic')
def traffic():
    return render_template('traffic.html')

@app.route('/rules')
def rules():
    all_rules = Rule.query.all()
    return render_template('rules.html', rules=all_rules)

@app.route('/alerts')
def alerts():
    return render_template('alerts.html')

@app.route('/api/traffic/stats')
def traffic_stats():
    # Default stats if the analyzer isn't ready yet
    default_stats = {
        'total_packets': 0,
        'tcp_packets': 0,
        'udp_packets': 0,
        'icmp_packets': 0,
        'other_packets': 0,
        'protocol_distribution': {},
        'top_source_ips': {},
        'top_destination_ips': {},
        'port_activity': {},
        'packet_rate': 0
    }
    
    try:
        # Use the global packet_analyzer if it exists
        global packet_analyzer
        if packet_analyzer is not None:
            # Get stats from the analyzer
            stats = packet_analyzer.get_traffic_stats()
            return jsonify(stats)
    except Exception as e:
        logger.error(f"Error fetching traffic stats: {str(e)}")
        
    # Return default stats if anything fails
    return jsonify(default_stats)

@app.route('/api/traffic/history')
def traffic_history():
    # Get last 60 snapshots (5 minutes if capturing every 5 seconds)
    snapshots = TrafficSnapshot.query.order_by(TrafficSnapshot.timestamp.desc()).limit(60).all()
    snapshots.reverse()  # Put in chronological order
    
    return jsonify([
        {
            'timestamp': s.timestamp,
            'total_packets': s.total_packets,
            'tcp_packets': s.tcp_packets,
            'udp_packets': s.udp_packets,
            'icmp_packets': s.icmp_packets,
            'other_packets': s.other_packets
        } for s in snapshots
    ])

@app.route('/api/alerts')
def get_alerts():
    # Get the latest 100 alerts
    alerts = Alert.query.order_by(Alert.timestamp.desc()).limit(100).all()
    return jsonify([
        {
            'id': a.id,
            'rule_id': a.rule_id,
            'rule_name': a.rule_name,
            'severity': a.severity,
            'timestamp': a.timestamp,
            'message': a.message,
            'source_ip': a.source_ip,
            'destination_ip': a.destination_ip,
            'protocol': a.protocol
        } for a in alerts
    ])

@app.route('/api/rules', methods=['GET'])
def get_rules():
    rules = Rule.query.all()
    return jsonify([
        {
            'id': r.id,
            'name': r.name,
            'description': r.description,
            'rule_type': r.rule_type,
            'protocol': r.protocol,
            'port': r.port,
            'pattern': r.pattern,
            'threshold': r.threshold,
            'time_window': r.time_window,
            'enabled': r.enabled
        } for r in rules
    ])

@app.route('/api/rules', methods=['POST'])
def add_rule():
    try:
        data = request.json
        new_rule = Rule(
            name=data.get('name'),
            description=data.get('description'),
            rule_type=data.get('rule_type'),
            protocol=data.get('protocol'),
            port=data.get('port'),
            pattern=data.get('pattern'),
            threshold=data.get('threshold'),
            time_window=data.get('time_window'),
            enabled=data.get('enabled', True)
        )
        db.session.add(new_rule)
        db.session.commit()
        
        # Update rule engine with new rule
        if rule_engine:
            rule_engine.add_rule(new_rule)
        
        return jsonify({'success': True, 'message': 'Rule added successfully', 'id': new_rule.id})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error adding rule: {str(e)}'}), 400

@app.route('/api/rules/<int:rule_id>', methods=['PUT'])
def update_rule(rule_id):
    try:
        rule = Rule.query.get(rule_id)
        if not rule:
            return jsonify({'success': False, 'message': 'Rule not found'}), 404
        
        data = request.json
        rule.name = data.get('name', rule.name)
        rule.description = data.get('description', rule.description)
        rule.rule_type = data.get('rule_type', rule.rule_type)
        rule.protocol = data.get('protocol', rule.protocol)
        rule.port = data.get('port', rule.port)
        rule.pattern = data.get('pattern', rule.pattern)
        rule.threshold = data.get('threshold', rule.threshold)
        rule.time_window = data.get('time_window', rule.time_window)
        rule.enabled = data.get('enabled', rule.enabled)
        
        db.session.commit()
        
        # Update rule in the rule engine
        if rule_engine:
            rule_engine.update_rule(rule)
        
        return jsonify({'success': True, 'message': 'Rule updated successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error updating rule: {str(e)}'}), 400

@app.route('/api/rules/<int:rule_id>', methods=['DELETE'])
def delete_rule(rule_id):
    try:
        rule = Rule.query.get(rule_id)
        if not rule:
            return jsonify({'success': False, 'message': 'Rule not found'}), 404
        
        db.session.delete(rule)
        db.session.commit()
        
        # Remove rule from the rule engine
        if rule_engine:
            rule_engine.remove_rule(rule_id)
        
        return jsonify({'success': True, 'message': 'Rule deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error deleting rule: {str(e)}'}), 400

@app.route('/api/capture/start', methods=['POST'])
def api_start_capture():
    start_capture()
    return jsonify({'success': True, 'message': 'Packet capture started'})

@app.route('/api/capture/stop', methods=['POST'])
def api_stop_capture():
    stop_capture()
    return jsonify({'success': True, 'message': 'Packet capture stopped'})

@app.route('/api/capture/status', methods=['GET'])
def capture_status():
    return jsonify({'running': capture_running})

# Function to properly initialize the database
def init_db():
    with app.app_context():
        # Check if we should re-create the tables
        inspector = db.inspect(db.engine)
        should_recreate = False
        
        # Check if the Alert table exists
        if 'alert' in inspector.get_table_names():
            # Check column types for the Alert table
            columns = inspector.get_columns('alert')
            for column in columns:
                if column['name'] == 'source_ip' or column['name'] == 'destination_ip':
                    # If we have existing columns that are too small, we need to recreate
                    try:
                        # SQLite and some other DBs report type differently
                        if isinstance(column['type'].length, int) and column['type'].length < 255:
                            should_recreate = True
                            break
                    except (AttributeError, TypeError):
                        # If we can't determine the length, we'll try to recreate anyway
                        should_recreate = True
                        break

        # For simplicity in this environment - we'll drop and recreate the tables
        # In a production environment, you'd use proper migrations with Alembic
        if should_recreate:
            try:
                logger.info("Dropping tables for schema update")
                db.drop_all()
            except Exception as e:
                logger.error(f"Error dropping tables: {str(e)}")
        
        # Create all tables in the database
        db.create_all()
        logger.info("Database tables created or verified")

# Initialize the database
init_db()

# Initialize components when the application starts
with app.app_context():
    initialize_components()
    # Start packet capture automatically on startup
    start_capture()
