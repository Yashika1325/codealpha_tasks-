import logging
import time
import random
import socket
import struct
from collections import defaultdict, Counter

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class PacketAnalyzer:
    def __init__(self, rule_engine, alert_manager):
        self.rule_engine = rule_engine
        self.alert_manager = alert_manager
        self.traffic_stats = {
            'total_packets': 0,
            'tcp_packets': 0,
            'udp_packets': 0,
            'icmp_packets': 0,
            'other_packets': 0,
            'protocol_distribution': {},
            'top_source_ips': {},
            'top_destination_ips': {},
            'port_activity': {},
            'packet_rate': 0
        }
        self.packet_buffer = []
        self.packet_count_history = []
        self.last_capture_time = 0
        self.start_time = 0
        
        # Track connection attempts for potential scans
        self.connection_attempts = defaultdict(lambda: defaultdict(set))
        # Packet counts for threshold-based detection
        self.packet_counts = defaultdict(Counter)
        
    def capture_packets(self, duration=5, interface=None):
        """
        Capture network packets for analysis
        
        Args:
            duration (int): Duration in seconds to capture
            interface (str): Network interface to capture on, None for default
        """
        try:
            self.start_time = time.time()
            logger.info(f"Starting packet capture for {duration} seconds")
            
            # In Replit environment, use simulated packet data instead of actually sniffing
            # This allows the application to function without real network access
            packets = self._simulate_packet_capture(duration, count=50)
            self.last_capture_time = time.time()
            
            # Process the captured packets
            self._process_packets(packets)
            
            # Calculate packet rate
            elapsed_time = self.last_capture_time - self.start_time
            if elapsed_time > 0:
                self.traffic_stats['packet_rate'] = len(packets) / elapsed_time
            
            logger.info(f"Captured {len(packets)} packets in {elapsed_time:.2f} seconds")
            
            # Apply rules to the captured packets
            self._apply_rules(packets)
            
            return len(packets)
        
        except Exception as e:
            logger.error(f"Error capturing packets: {str(e)}")
            return 0
            
    def _simulate_packet_capture(self, duration, count=50):
        """
        Simulate packet capture with realistic network data
        This is used when running in environments where actual packet capture is not possible
        
        Args:
            duration (int): Duration to simulate
            count (int): Number of packets to simulate
            
        Returns:
            List of simulated packet objects
        """
        # Define a simple packet class to replace Scapy's functionality
        class SimPacket:
            def __init__(self, src_ip, dst_ip, protocol, sport=None, dport=None):
                self.src_ip = src_ip
                self.dst_ip = dst_ip
                self.protocol = protocol
                self.sport = sport
                self.dport = dport
                
            def __contains__(self, protocol_name):
                return self.protocol == protocol_name
                
            def __getitem__(self, protocol_name):
                if protocol_name == 'IP':
                    return self
                elif protocol_name == self.protocol:
                    return self
                return None
                
        # Define protocol constants that used to be imported from Scapy
        class ProtocolType:
            IP = 'IP'
            TCP = 'TCP'
            UDP = 'UDP'
            ICMP = 'ICMP'
            
        # Use these constants as replacements for the imported ones
        IP = ProtocolType.IP
        TCP = ProtocolType.TCP
        UDP = ProtocolType.UDP
        ICMP = ProtocolType.ICMP
        
        # Common IPs for simulation
        source_ips = ['192.168.1.100', '192.168.1.101', '192.168.1.102', '10.0.0.5', '10.0.0.10', '172.16.0.15']
        dest_ips = ['192.168.1.1', '8.8.8.8', '1.1.1.1', '208.67.222.222', '172.217.164.110', '151.101.129.140']
        
        # Common ports
        common_ports = {
            TCP: [80, 443, 22, 21, 25, 110, 143, 3389, 3306, 5432],
            UDP: [53, 123, 161, 5353, 514, 1900, 67, 68]
        }
        
        # Generate simulated packets
        packets = []
        for _ in range(count):
            # Randomly select protocol: 60% TCP, 30% UDP, 10% ICMP
            protocol = random.choices([TCP, UDP, ICMP], weights=[60, 30, 10])[0]
            
            # Select source and destination IPs
            src_ip = random.choice(source_ips)
            dst_ip = random.choice(dest_ips)
            
            if protocol == TCP:
                # Create TCP packet
                sport = random.randint(1024, 65535)
                dport = random.choice(common_ports[TCP])
                packet = SimPacket(src_ip, dst_ip, TCP, sport, dport)
                packets.append(packet)
            elif protocol == UDP:
                # Create UDP packet
                sport = random.randint(1024, 65535)
                dport = random.choice(common_ports[UDP])
                packet = SimPacket(src_ip, dst_ip, UDP, sport, dport)
                packets.append(packet)
            else:
                # Create ICMP packet
                packet = SimPacket(src_ip, dst_ip, ICMP)
                packets.append(packet)
                
        # Simulate some threshold and signature trigger packets
        # Occasionally simulate port scan
        if random.random() < 0.1:  # 10% chance
            src_ip = random.choice(source_ips)
            dst_ip = random.choice(dest_ips)
            for port in range(20):
                scan_pkt = SimPacket(src_ip, dst_ip, TCP, random.randint(1024, 65535), port+1)
                packets.append(scan_pkt)
                
        # Occasionally simulate ICMP flood
        if random.random() < 0.05:  # 5% chance
            src_ip = random.choice(source_ips)
            dst_ip = random.choice(dest_ips)
            for _ in range(15):
                icmp_flood_pkt = SimPacket(src_ip, dst_ip, ICMP)
                packets.append(icmp_flood_pkt)
                
        # Sleep to simulate duration
        time.sleep(min(duration, 2))  # Sleep at most 2 seconds to keep UI responsive
        
        return packets
    
    def _process_packets(self, packets):
        """Process captured packets and update statistics"""
        # Define protocol constants that were defined in _simulate_packet_capture
        class ProtocolType:
            IP = 'IP'
            TCP = 'TCP'
            UDP = 'UDP'
            ICMP = 'ICMP'
            
        # Use these constants
        IP = ProtocolType.IP
        TCP = ProtocolType.TCP
        UDP = ProtocolType.UDP
        ICMP = ProtocolType.ICMP
        
        # Reset per-capture stats
        self.traffic_stats['protocol_distribution'] = {}
        self.traffic_stats['top_source_ips'] = {}
        self.traffic_stats['top_destination_ips'] = {}
        self.traffic_stats['port_activity'] = {}
        
        # Track source and destination IPs
        src_ips = Counter()
        dst_ips = Counter()
        port_activity = Counter()
        protocols = Counter()
        
        # Update traffic statistics
        self.traffic_stats['total_packets'] += len(packets)
        
        for packet in packets:
            # Store packet in buffer for analysis
            self.packet_buffer.append(packet)
            if len(self.packet_buffer) > 10000:  # Limit buffer size
                self.packet_buffer.pop(0)
            
            # Access packet attributes
            src_ip = packet.src_ip
            dst_ip = packet.dst_ip
            protocol = packet.protocol
            
            # Update counters
            src_ips[src_ip] += 1
            dst_ips[dst_ip] += 1
            protocols[protocol] += 1
            
            # Update protocol-specific counters
            if protocol == TCP:
                self.traffic_stats['tcp_packets'] += 1
                if packet.dport:
                    port_activity[f"TCP:{packet.dport}"] += 1
                    # Track connection attempts for scan detection
                    self.connection_attempts[src_ip][dst_ip].add(packet.dport)
            elif protocol == UDP:
                self.traffic_stats['udp_packets'] += 1
                if packet.dport:
                    port_activity[f"UDP:{packet.dport}"] += 1
            elif protocol == ICMP:
                self.traffic_stats['icmp_packets'] += 1
            else:
                self.traffic_stats['other_packets'] += 1
        
        # Update statistics
        self.traffic_stats['protocol_distribution'] = dict(protocols)
        self.traffic_stats['top_source_ips'] = dict(src_ips.most_common(10))
        self.traffic_stats['top_destination_ips'] = dict(dst_ips.most_common(10))
        self.traffic_stats['port_activity'] = dict(port_activity.most_common(15))
        
        # Update packet count history for rate analysis
        timestamp = int(time.time())
        self.packet_count_history.append((timestamp, len(packets)))
        
        # Keep only the last hour of history
        one_hour_ago = timestamp - 3600
        self.packet_count_history = [item for item in self.packet_count_history 
                                    if item[0] >= one_hour_ago]
        
    def _apply_rules(self, packets):
        """Apply detection rules to the captured packets"""
        # Apply rules from the rule engine
        alerts = self.rule_engine.analyze_packets(packets, self.connection_attempts, 
                                                  self.packet_counts, self.traffic_stats)
        
        # Send alerts to the alert manager
        for alert in alerts:
            self.alert_manager.add_alert(alert)
        
        # Clean up old data in packet counts and connection attempts
        self._cleanup_tracking_data()
    
    def _cleanup_tracking_data(self):
        """Clean up old tracking data to prevent memory leaks"""
        current_time = time.time()
        
        # Remove old connection attempts (older than 5 minutes)
        five_minutes_ago = current_time - 300
        for src_ip in list(self.connection_attempts.keys()):
            # We don't have timestamps here, so we'll periodically reset this
            # This is just a simple periodic cleanup
            if current_time % 300 < 5:  # Every 5 minutes approximately
                self.connection_attempts = defaultdict(lambda: defaultdict(set))
                break

        # Clean up packet counts (keep counts within individual rule time windows)
        # This will be handled by the rule engine in analyze_packets
    
    def get_traffic_stats(self):
        """Get current traffic statistics"""
        # Ensure all expected keys are present in the stats
        default_stats = {
            'total_packets': 0,
            'tcp_packets': 0,
            'udp_packets': 0,
            'icmp_packets': 0,
            'other_packets': 0,
            'protocol_distribution': {},
            'top_source_ips': {},
            'top_destination_ips': {},
            'port_activity': {},
            'packet_rate': 0
        }
        
        # Create a copy of the stats to avoid modifying the original
        stats = dict(self.traffic_stats)
        
        # Fill in any missing keys with default values
        for key, default_value in default_stats.items():
            if key not in stats:
                stats[key] = default_value
        
        return stats
    
    def analyze_packet_rate(self, window_seconds=60):
        """Analyze packet rate over a time window"""
        now = int(time.time())
        window_start = now - window_seconds
        
        # Filter packet history to the window
        window_history = [item for item in self.packet_count_history 
                        if item[0] >= window_start]
        
        if not window_history:
            return 0
        
        # Calculate total packets in window
        total_packets = sum(count for _, count in window_history)
        
        # Calculate rate: packets per second
        return total_packets / window_seconds if window_seconds > 0 else 0
