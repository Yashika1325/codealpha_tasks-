import logging
import time
import random

logger = logging.getLogger(__name__)

class RuleEngine:
    def __init__(self, rules=None):
        self.rules = rules or []
        # Track alerts to prevent duplicates
        self.alert_history = {}
        # Track last cleanup time
        self.last_cleanup = time.time()
    
    def add_rule(self, rule):
        """Add a new rule to the engine"""
        self.rules.append(rule)
    
    def update_rule(self, updated_rule):
        """Update an existing rule"""
        for i, rule in enumerate(self.rules):
            if rule.id == updated_rule.id:
                self.rules[i] = updated_rule
                return True
        return False
    
    def remove_rule(self, rule_id):
        """Remove a rule from the engine"""
        self.rules = [rule for rule in self.rules if rule.id != rule_id]
    
    def analyze_packets(self, packets, connection_attempts, packet_counts, traffic_stats):
        """
        Analyze packets against defined rules
        
        Args:
            packets: List of captured packets
            connection_attempts: Dictionary tracking connection attempts
            packet_counts: Dictionary tracking packet counts
            traffic_stats: Current traffic statistics
            
        Returns:
            List of generated alerts
        """
        alerts = []
        current_time = time.time()
        
        # Clean up old packet counts
        self._cleanup_packet_counts(packet_counts, current_time)
        
        # Apply each rule to the packets
        for rule in self.rules:
            if not rule.enabled:
                continue
                
            try:
                if rule.rule_type == 'signature':
                    new_alerts = self._apply_signature_rule(rule, packets)
                    alerts.extend(new_alerts)
                    
                elif rule.rule_type == 'threshold':
                    new_alerts = self._apply_threshold_rule(rule, packets, packet_counts, current_time)
                    alerts.extend(new_alerts)
                    
                elif rule.rule_type == 'anomaly':
                    new_alerts = self._apply_anomaly_rule(rule, packets, connection_attempts, traffic_stats)
                    alerts.extend(new_alerts)
            
            except Exception as e:
                logger.error(f"Error applying rule {rule.name}: {str(e)}")
        
        return alerts
    
    def _cleanup_packet_counts(self, packet_counts, current_time):
        """Clean up old packet counts"""
        # Find the maximum time window from all rules
        max_window = 3600  # Default: 1 hour
        for rule in self.rules:
            if rule.rule_type == 'threshold' and rule.time_window:
                max_window = max(max_window, rule.time_window)
        
        # Clean up counts older than the maximum window
        cutoff_time = current_time - max_window
        
        for rule_id in list(packet_counts.keys()):
            for timestamp in list(packet_counts[rule_id].keys()):
                if timestamp < cutoff_time:
                    del packet_counts[rule_id][timestamp]
    
    def _apply_signature_rule(self, rule, packets):
        """Apply signature-based detection rule"""
        alerts = []
        
        if not rule.pattern:
            return alerts
            
        for packet in packets:
            match = False
            
            # Check if the packet matches the rule's protocol
            protocol_match = False
            
            if rule.protocol.lower() == 'tcp' and packet.protocol == 'TCP':
                protocol_match = True
                # Match on port if specified
                if rule.port and packet.dport and packet.dport != rule.port:
                    protocol_match = False
                    
            elif rule.protocol.lower() == 'udp' and packet.protocol == 'UDP':
                protocol_match = True
                # Match on port if specified
                if rule.port and packet.dport and packet.dport != rule.port:
                    protocol_match = False
                    
            elif rule.protocol.lower() == 'icmp' and packet.protocol == 'ICMP':
                protocol_match = True
            
            if protocol_match:
                # Simple pattern matching using packet attributes
                # In a real system, this would be more sophisticated
                packet_str = f"{packet.src_ip}:{packet.dst_ip}:{packet.protocol}"
                if packet.dport:
                    packet_str += f":{packet.dport}"
                if rule.pattern.lower() in packet_str.lower():
                    match = True
            
            if match:
                # Create an alert for the match
                alert = {
                    'rule_id': rule.id,
                    'rule_name': rule.name,
                    'severity': 'medium',  # Default severity
                    'timestamp': int(time.time()),
                    'message': f"Signature match: {rule.pattern}",
                    'source_ip': packet.src_ip,
                    'destination_ip': packet.dst_ip,
                    'protocol': rule.protocol
                }
                
                # Deduplicate alerts
                alert_key = f"{alert['rule_id']}_{alert['source_ip']}_{alert['destination_ip']}"
                if alert_key not in self.alert_history or \
                   (time.time() - self.alert_history[alert_key]) > 300:  # 5 minutes
                    alerts.append(alert)
                    self.alert_history[alert_key] = time.time()
        
        return alerts
    
    def _apply_threshold_rule(self, rule, packets, packet_counts, current_time):
        """Apply threshold-based detection rule"""
        alerts = []
        
        if not rule.threshold or not rule.time_window:
            return alerts
        
        # Group packets into time-based buckets (1-second granularity)
        current_bucket = int(current_time)
        
        # Count matching packets
        count = 0
        source_ips = set()
        destination_ips = set()
        
        for packet in packets:
            protocol_match = False
            
            if rule.protocol.lower() == 'tcp' and packet.protocol == 'TCP':
                protocol_match = True
                if rule.port and packet.dport and packet.dport != rule.port:
                    protocol_match = False
                    
            elif rule.protocol.lower() == 'udp' and packet.protocol == 'UDP':
                protocol_match = True
                if rule.port and packet.dport and packet.dport != rule.port:
                    protocol_match = False
                    
            elif rule.protocol.lower() == 'icmp' and packet.protocol == 'ICMP':
                protocol_match = True
            
            if protocol_match:
                # Count the packet
                count += 1
                source_ips.add(packet.src_ip)
                destination_ips.add(packet.dst_ip)
        
        # Add to the running counts
        if count > 0:
            packet_counts[rule.id][current_bucket] += count
        
        # Check if threshold is exceeded within the time window
        window_start = current_time - rule.time_window
        window_buckets = [ts for ts in packet_counts[rule.id].keys() 
                         if ts >= window_start]
        
        total_count = sum(packet_counts[rule.id][ts] for ts in window_buckets)
        
        if total_count >= rule.threshold:
            # Create an alert
            alert = {
                'rule_id': rule.id,
                'rule_name': rule.name,
                'severity': 'high',  # Threshold violations are high severity
                'timestamp': int(current_time),
                'message': f"Threshold exceeded: {total_count} packets in {rule.time_window}s (threshold: {rule.threshold})",
                'source_ip': ','.join(list(source_ips)[:5]),  # Limit to first 5
                'destination_ip': ','.join(list(destination_ips)[:5]),  # Limit to first 5
                'protocol': rule.protocol
            }
            
            # Deduplicate alerts
            alert_key = f"{alert['rule_id']}_threshold"
            if alert_key not in self.alert_history or \
               (current_time - self.alert_history[alert_key]) > 300:  # 5 minutes
                alerts.append(alert)
                self.alert_history[alert_key] = current_time
        
        return alerts
    
    def _apply_anomaly_rule(self, rule, packets, connection_attempts, traffic_stats):
        """Apply anomaly-based detection rule"""
        alerts = []
        current_time = time.time()
        
        # Port scan detection
        if rule.name.lower().find('port scan') >= 0:
            for src_ip, targets in connection_attempts.items():
                for dst_ip, ports in targets.items():
                    # If a source has attempted connections to many ports on the same destination
                    if len(ports) > 15:  # Arbitrary threshold for port scanning
                        alert = {
                            'rule_id': rule.id,
                            'rule_name': rule.name,
                            'severity': 'medium',
                            'timestamp': int(current_time),
                            'message': f"Possible port scan detected: {len(ports)} ports scanned",
                            'source_ip': src_ip,
                            'destination_ip': dst_ip,
                            'protocol': 'TCP'  # Assuming TCP scan
                        }
                        
                        # Deduplicate alerts
                        alert_key = f"portscan_{src_ip}_{dst_ip}"
                        if alert_key not in self.alert_history or \
                           (current_time - self.alert_history[alert_key]) > 600:  # 10 minutes
                            alerts.append(alert)
                            self.alert_history[alert_key] = current_time
        
        # ICMP flood detection
        elif rule.protocol.lower() == 'icmp' and 'icmp_packets' in traffic_stats:
            # Simple rate-based detection
            if traffic_stats['icmp_packets'] > 20:  # Arbitrary threshold
                alert = {
                    'rule_id': rule.id,
                    'rule_name': rule.name,
                    'severity': 'medium',
                    'timestamp': int(current_time),
                    'message': f"Possible ICMP flood: {traffic_stats['icmp_packets']} ICMP packets",
                    'source_ip': "multiple",
                    'destination_ip': "multiple",
                    'protocol': 'ICMP'
                }
                
                # Deduplicate alerts
                alert_key = f"icmpflood_{rule.id}"
                if alert_key not in self.alert_history or \
                   (current_time - self.alert_history[alert_key]) > 300:  # 5 minutes
                    alerts.append(alert)
                    self.alert_history[alert_key] = current_time
        
        # DNS amplification attack detection
        elif rule.protocol.lower() == 'udp' and rule.port == 53:
            # Check for DNS response size anomalies
            large_dns_responses = 0
            
            for packet in packets:
                if packet.protocol == 'UDP' and packet.dport and packet.dport == 53:
                    # Simple heuristic for detection - in a real system we'd check packet length
                    # but for simulation, we'll just randomly flag some packets
                    if random.random() < 0.1:  # 10% of UDP/53 packets flagged as "large"
                        large_dns_responses += 1
            
            if large_dns_responses > 5:  # Arbitrary threshold
                alert = {
                    'rule_id': rule.id,
                    'rule_name': rule.name,
                    'severity': 'high',
                    'timestamp': int(current_time),
                    'message': f"Possible DNS amplification: {large_dns_responses} large DNS responses",
                    'source_ip': "multiple",
                    'destination_ip': "multiple",
                    'protocol': 'UDP'
                }
                
                # Deduplicate alerts
                alert_key = f"dnsamplification_{rule.id}"
                if alert_key not in self.alert_history or \
                   (current_time - self.alert_history[alert_key]) > 300:  # 5 minutes
                    alerts.append(alert)
                    self.alert_history[alert_key] = current_time
        
        return alerts
