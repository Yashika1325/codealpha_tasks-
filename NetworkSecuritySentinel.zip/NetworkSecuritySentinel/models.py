from app import db
import time

class Rule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(500))
    rule_type = db.Column(db.String(50), nullable=False)  # 'signature', 'threshold', 'anomaly'
    protocol = db.Column(db.String(10))  # 'tcp', 'udp', 'icmp', etc.
    port = db.Column(db.Integer)  # Specific port to monitor
    pattern = db.Column(db.String(500))  # Pattern to match for signature-based rules
    threshold = db.Column(db.Integer)  # Threshold for threshold-based rules
    time_window = db.Column(db.Integer)  # Time window in seconds for threshold rules
    enabled = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Rule {self.name}>'

class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rule_id = db.Column(db.Integer, db.ForeignKey('rule.id'))
    rule_name = db.Column(db.String(100))
    severity = db.Column(db.String(20), default='medium')  # 'low', 'medium', 'high', 'critical'
    timestamp = db.Column(db.Integer, default=lambda: int(time.time()))
    message = db.Column(db.String(500))
    source_ip = db.Column(db.String(255))  # Increased length for multiple IPs
    destination_ip = db.Column(db.String(255))  # Increased length for multiple IPs
    protocol = db.Column(db.String(10))
    
    def __repr__(self):
        return f'<Alert {self.id}: {self.rule_name}>'

class TrafficSnapshot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.Integer, default=lambda: int(time.time()))
    total_packets = db.Column(db.Integer, default=0)
    tcp_packets = db.Column(db.Integer, default=0)
    udp_packets = db.Column(db.Integer, default=0)
    icmp_packets = db.Column(db.Integer, default=0)
    other_packets = db.Column(db.Integer, default=0)
    
    def __repr__(self):
        return f'<TrafficSnapshot {self.timestamp}>'
