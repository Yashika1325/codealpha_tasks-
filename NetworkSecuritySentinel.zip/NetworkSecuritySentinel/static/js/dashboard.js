// dashboard.js - Main dashboard functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard components
    initDashboard();
    
    // Set up refresh interval (every 10 seconds)
    setInterval(updateDashboard, 10000);
});

// Dashboard initialization
function initDashboard() {
    // Load initial data
    updateTrafficStats();
    updateAlertSummary();
    updateCaptureStatus();
    
    // Set up event listeners for capture controls
    document.getElementById('startCaptureBtn')?.addEventListener('click', startCapture);
    document.getElementById('stopCaptureBtn')?.addEventListener('click', stopCapture);
}

// Update all dashboard components
function updateDashboard() {
    updateTrafficStats();
    updateAlertSummary();
    updateCaptureStatus();
}

// Update traffic statistics
function updateTrafficStats() {
    fetch('/api/traffic/stats')
        .then(response => response.json())
        .then(data => {
            // Update traffic statistics cards
            document.getElementById('totalPackets').textContent = data.total_packets || 0;
            document.getElementById('tcpPackets').textContent = data.tcp_packets || 0;
            document.getElementById('udpPackets').textContent = data.udp_packets || 0;
            document.getElementById('icmpPackets').textContent = data.icmp_packets || 0;
            document.getElementById('packetRate').textContent = 
                data.packet_rate ? data.packet_rate.toFixed(2) + ' pps' : '0 pps';
            
            // Update protocol distribution if chart exists
            if (window.protocolChart) {
                const protocolData = data.protocol_distribution || {};
                window.protocolChart.data.labels = Object.keys(protocolData);
                window.protocolChart.data.datasets[0].data = Object.values(protocolData);
                window.protocolChart.update();
            } else if (document.getElementById('protocolChart')) {
                // Initialize protocol distribution chart
                const protocolData = data.protocol_distribution || {};
                const ctx = document.getElementById('protocolChart').getContext('2d');
                window.protocolChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: Object.keys(protocolData),
                        datasets: [{
                            data: Object.values(protocolData),
                            backgroundColor: [
                                '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b'
                            ],
                            hoverBackgroundColor: [
                                '#2e59d9', '#17a673', '#2c9faf', '#dda20a', '#be2617'
                            ],
                            hoverBorderColor: "rgba(234, 236, 244, 1)",
                        }],
                    },
                    options: {
                        maintainAspectRatio: false,
                        responsive: true,
                        legend: {
                            position: 'bottom',
                            labels: {
                                fontColor: '#858796'
                            }
                        },
                        cutoutPercentage: 70,
                        plugins: {
                            title: {
                                display: true,
                                text: 'Protocol Distribution'
                            }
                        }
                    },
                });
            }
            
            // Update top source IPs table
            updateTopIPsTable('topSourceIPs', data.top_source_ips);
            
            // Update top destination IPs table
            updateTopIPsTable('topDestinationIPs', data.top_destination_ips);
            
            // Update port activity table
            updatePortActivityTable('portActivity', data.port_activity);
        })
        .catch(error => {
            console.error('Error fetching traffic stats:', error);
        });
}

// Update table with IP address data
function updateTopIPsTable(tableId, ipData) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    
    // Clear existing rows
    tbody.innerHTML = '';
    
    // Add new rows
    if (ipData && Object.keys(ipData).length > 0) {
        Object.entries(ipData).forEach(([ip, count]) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${ip}</td>
                <td class="text-right">${count}</td>
            `;
            tbody.appendChild(row);
        });
    } else {
        // No data
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="2" class="text-center">No data available</td>
        `;
        tbody.appendChild(row);
    }
}

// Update port activity table
function updatePortActivityTable(tableId, portData) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    
    // Clear existing rows
    tbody.innerHTML = '';
    
    // Add new rows
    if (portData && Object.keys(portData).length > 0) {
        Object.entries(portData).forEach(([port, count]) => {
            const row = document.createElement('tr');
            const [protocol, portNumber] = port.split(':');
            row.innerHTML = `
                <td>${protocol}</td>
                <td>${portNumber || 'N/A'}</td>
                <td class="text-right">${count}</td>
            `;
            tbody.appendChild(row);
        });
    } else {
        // No data
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="3" class="text-center">No data available</td>
        `;
        tbody.appendChild(row);
    }
}

// Update alert summary
function updateAlertSummary() {
    fetch('/api/alerts')
        .then(response => response.json())
        .then(alerts => {
            // Get the alert container
            const alertContainer = document.getElementById('recentAlerts');
            if (!alertContainer) return;
            
            // Clear existing alerts
            alertContainer.innerHTML = '';
            
            // Add new alerts (limit to 5 most recent)
            const recentAlerts = alerts.slice(0, 5);
            
            if (recentAlerts.length > 0) {
                recentAlerts.forEach(alert => {
                    const alertTime = new Date(alert.timestamp * 1000);
                    const timeString = alertTime.toLocaleTimeString();
                    
                    // Determine alert class based on severity
                    let alertClass = 'alert-warning';
                    if (alert.severity === 'high') {
                        alertClass = 'alert-danger';
                    } else if (alert.severity === 'low') {
                        alertClass = 'alert-info';
                    }
                    
                    const alertElement = document.createElement('div');
                    alertElement.className = `alert ${alertClass} alert-dismissible fade show`;
                    alertElement.innerHTML = `
                        <strong>${alert.rule_name}</strong> - ${alert.message}
                        <br>
                        <small>Source: ${alert.source_ip} → ${alert.destination_ip} (${alert.protocol}) at ${timeString}</small>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    `;
                    
                    alertContainer.appendChild(alertElement);
                });
            } else {
                // No alerts
                const noAlertsMsg = document.createElement('div');
                noAlertsMsg.className = 'alert alert-secondary';
                noAlertsMsg.textContent = 'No recent alerts';
                alertContainer.appendChild(noAlertsMsg);
            }
            
            // Update alert count badges
            const totalAlerts = alerts.length;
            const highSeverity = alerts.filter(a => a.severity === 'high').length;
            const mediumSeverity = alerts.filter(a => a.severity === 'medium').length;
            const lowSeverity = alerts.filter(a => a.severity === 'low').length;
            
            document.getElementById('totalAlertCount').textContent = totalAlerts;
            document.getElementById('highSeverityCount').textContent = highSeverity;
            document.getElementById('mediumSeverityCount').textContent = mediumSeverity;
            document.getElementById('lowSeverityCount').textContent = lowSeverity;
        })
        .catch(error => {
            console.error('Error fetching alerts:', error);
        });
}

// Update capture status
function updateCaptureStatus() {
    fetch('/api/capture/status')
        .then(response => response.json())
        .then(data => {
            const startBtn = document.getElementById('startCaptureBtn');
            const stopBtn = document.getElementById('stopCaptureBtn');
            const statusIndicator = document.getElementById('captureStatus');
            
            if (startBtn && stopBtn && statusIndicator) {
                if (data.running) {
                    // Capture is running
                    startBtn.disabled = true;
                    stopBtn.disabled = false;
                    statusIndicator.className = 'badge bg-success';
                    statusIndicator.textContent = 'Active';
                } else {
                    // Capture is stopped
                    startBtn.disabled = false;
                    stopBtn.disabled = true;
                    statusIndicator.className = 'badge bg-danger';
                    statusIndicator.textContent = 'Stopped';
                }
            }
        })
        .catch(error => {
            console.error('Error fetching capture status:', error);
        });
}

// Start packet capture
function startCapture() {
    fetch('/api/capture/start', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCaptureStatus();
            showToast('Packet capture started successfully');
        } else {
            showToast('Failed to start packet capture', 'danger');
        }
    })
    .catch(error => {
        console.error('Error starting capture:', error);
        showToast('Error starting packet capture', 'danger');
    });
}

// Stop packet capture
function stopCapture() {
    fetch('/api/capture/stop', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCaptureStatus();
            showToast('Packet capture stopped successfully');
        } else {
            showToast('Failed to stop packet capture', 'danger');
        }
    })
    .catch(error => {
        console.error('Error stopping capture:', error);
        showToast('Error stopping packet capture', 'danger');
    });
}

// Show toast notification
function showToast(message, type = 'success') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.setAttribute('id', toastId);
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Initialize and show the toast
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 3000
    });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}
