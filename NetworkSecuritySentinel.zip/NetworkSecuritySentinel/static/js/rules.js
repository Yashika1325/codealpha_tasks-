// rules.js - Rule management functionality

document.addEventListener('DOMContentLoaded', function() {
    initRulesTable();
    
    // Set up form event handlers
    const ruleForm = document.getElementById('ruleForm');
    if (ruleForm) {
        ruleForm.addEventListener('submit', handleRuleSubmit);
    }
    
    // Set up rule type change handler to show/hide relevant fields
    const ruleTypeSelect = document.getElementById('ruleType');
    if (ruleTypeSelect) {
        ruleTypeSelect.addEventListener('change', updateFormFields);
        // Initialize form fields based on initial selection
        updateFormFields();
    }
});

let rulesTable = null;
let currentRuleId = null;

// Initialize rules DataTable
function initRulesTable() {
    const rulesTableElement = document.getElementById('rulesTable');
    
    if (rulesTableElement) {
        rulesTable = new DataTable('#rulesTable', {
            columns: [
                { data: 'id' },
                { data: 'name' },
                { data: 'rule_type' },
                { data: 'protocol' },
                { data: 'enabled',
                  render: function(data) {
                      const badgeClass = data ? 'bg-success' : 'bg-danger';
                      const status = data ? 'Enabled' : 'Disabled';
                      return `<span class="badge ${badgeClass}">${status}</span>`;
                  }
                },
                { 
                  data: null,
                  defaultContent: '',
                  render: function(data, type, row) {
                      return `
                        <button class="btn btn-sm btn-primary edit-rule" data-id="${row.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger delete-rule" data-id="${row.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                      `;
                  }
                }
            ],
            pageLength: 15,
            language: {
                emptyTable: "No rules defined"
            }
        });
        
        // Load initial rules
        loadRules();
        
        // Set up click handlers for edit and delete buttons
        $('#rulesTable tbody').on('click', 'button.edit-rule', function() {
            const data = rulesTable.row($(this).parents('tr')).data();
            editRule(data);
        });
        
        $('#rulesTable tbody').on('click', 'button.delete-rule', function() {
            const data = rulesTable.row($(this).parents('tr')).data();
            deleteRule(data.id);
        });
    }
}

// Load rules from API
function loadRules() {
    if (!rulesTable) return;
    
    fetch('/api/rules')
        .then(response => response.json())
        .then(data => {
            // Clear and load new data
            rulesTable.clear();
            rulesTable.rows.add(data).draw();
        })
        .catch(error => {
            console.error('Error fetching rules:', error);
            showToast('Error loading rules', 'danger');
        });
}

// Show rule form modal for editing
function editRule(rule) {
    // Set current rule ID
    currentRuleId = rule.id;
    
    // Fill form with rule data
    document.getElementById('ruleName').value = rule.name;
    document.getElementById('ruleDescription').value = rule.description;
    document.getElementById('ruleType').value = rule.rule_type;
    document.getElementById('ruleProtocol').value = rule.protocol;
    document.getElementById('rulePort').value = rule.port || '';
    document.getElementById('rulePattern').value = rule.pattern || '';
    document.getElementById('ruleThreshold').value = rule.threshold || '';
    document.getElementById('ruleTimeWindow').value = rule.time_window || '';
    document.getElementById('ruleEnabled').checked = rule.enabled;
    
    // Update form fields based on rule type
    updateFormFields();
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('ruleModal'));
    modal.show();
    
    // Update modal title
    document.getElementById('ruleModalLabel').textContent = 'Edit Rule';
}

// Delete a rule
function deleteRule(ruleId) {
    if (confirm('Are you sure you want to delete this rule?')) {
        fetch(`/api/rules/${ruleId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadRules();
                showToast('Rule deleted successfully');
            } else {
                showToast('Failed to delete rule: ' + data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error deleting rule:', error);
            showToast('Error deleting rule', 'danger');
        });
    }
}

// Handle rule form submission
function handleRuleSubmit(event) {
    event.preventDefault();
    
    // Get form data
    const formData = {
        name: document.getElementById('ruleName').value,
        description: document.getElementById('ruleDescription').value,
        rule_type: document.getElementById('ruleType').value,
        protocol: document.getElementById('ruleProtocol').value,
        port: parseInt(document.getElementById('rulePort').value) || null,
        pattern: document.getElementById('rulePattern').value || null,
        threshold: parseInt(document.getElementById('ruleThreshold').value) || null,
        time_window: parseInt(document.getElementById('ruleTimeWindow').value) || null,
        enabled: document.getElementById('ruleEnabled').checked
    };
    
    // Validate form
    if (!formData.name) {
        showToast('Rule name is required', 'danger');
        return;
    }
    
    if (!formData.rule_type) {
        showToast('Rule type is required', 'danger');
        return;
    }
    
    if (!formData.protocol) {
        showToast('Protocol is required', 'danger');
        return;
    }
    
    // Additional validation based on rule type
    if (formData.rule_type === 'signature' && !formData.pattern) {
        showToast('Pattern is required for signature-based rules', 'danger');
        return;
    }
    
    if (formData.rule_type === 'threshold' && (!formData.threshold || !formData.time_window)) {
        showToast('Threshold and time window are required for threshold-based rules', 'danger');
        return;
    }
    
    // Determine if this is an update or create
    let url = '/api/rules';
    let method = 'POST';
    
    if (currentRuleId) {
        url = `/api/rules/${currentRuleId}`;
        method = 'PUT';
    }
    
    // Submit the form
    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Close the modal
            const modalElement = document.getElementById('ruleModal');
            const modal = bootstrap.Modal.getInstance(modalElement);
            modal.hide();
            
            // Reset form
            document.getElementById('ruleForm').reset();
            currentRuleId = null;
            
            // Reload rules
            loadRules();
            
            // Show success message
            showToast(currentRuleId ? 'Rule updated successfully' : 'Rule created successfully');
        } else {
            showToast('Error: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error saving rule:', error);
        showToast('Error saving rule', 'danger');
    });
}

// Update form fields based on selected rule type
function updateFormFields() {
    const ruleType = document.getElementById('ruleType').value;
    
    // Get form field containers
    const patternGroup = document.getElementById('patternGroup');
    const thresholdGroup = document.getElementById('thresholdGroup');
    const timeWindowGroup = document.getElementById('timeWindowGroup');
    
    // Show/hide fields based on rule type
    if (ruleType === 'signature') {
        patternGroup.style.display = 'block';
        thresholdGroup.style.display = 'none';
        timeWindowGroup.style.display = 'none';
    } else if (ruleType === 'threshold') {
        patternGroup.style.display = 'none';
        thresholdGroup.style.display = 'block';
        timeWindowGroup.style.display = 'block';
    } else if (ruleType === 'anomaly') {
        patternGroup.style.display = 'none';
        thresholdGroup.style.display = 'block';
        timeWindowGroup.style.display = 'block';
    }
}

// Show new rule modal
function showNewRuleModal() {
    // Reset form
    document.getElementById('ruleForm').reset();
    currentRuleId = null;
    
    // Reset modal title
    document.getElementById('ruleModalLabel').textContent = 'Add New Rule';
    
    // Update form fields
    updateFormFields();
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('ruleModal'));
    modal.show();
}

// Show toast notification
function showToast(message, type = 'success') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.setAttribute('id', toastId);
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Initialize and show the toast
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 3000
    });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}
