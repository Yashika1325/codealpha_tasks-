// alerts.js - Alert management functionality

document.addEventListener('DOMContentLoaded', function() {
    initAlertTable();
    
    // Set up refresh interval (every 15 seconds)
    setInterval(updateAlerts, 15000);
});

let alertsTable = null;

// Initialize alerts DataTable
function initAlertTable() {
    const alertsTableElement = document.getElementById('alertsTable');
    
    if (alertsTableElement) {
        alertsTable = new DataTable('#alertsTable', {
            order: [[3, 'desc']], // Sort by timestamp descending
            columns: [
                { data: 'id' },
                { data: 'rule_name' },
                { data: 'severity', 
                  render: function(data) {
                      let badgeClass = 'bg-warning';
                      if (data === 'high') {
                          badgeClass = 'bg-danger';
                      } else if (data === 'low') {
                          badgeClass = 'bg-info';
                      }
                      return `<span class="badge ${badgeClass}">${data}</span>`;
                  }
                },
                { data: 'timestamp',
                  render: function(data) {
                      const date = new Date(data * 1000);
                      return date.toLocaleString();
                  }
                },
                { data: 'message' },
                { data: 'source_ip' },
                { data: 'destination_ip' },
                { data: 'protocol' }
            ],
            pageLength: 25,
            language: {
                emptyTable: "No alerts have been detected"
            },
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
        
        // Load initial data
        updateAlerts();
    }
    
    // Set up alert severity filters
    document.querySelectorAll('.alert-severity-filter').forEach(button => {
        button.addEventListener('click', function() {
            const severity = this.getAttribute('data-severity');
            
            // Toggle active state
            document.querySelectorAll('.alert-severity-filter').forEach(btn => {
                btn.classList.remove('active');
            });
            this.classList.add('active');
            
            // Apply filter
            if (severity === 'all') {
                alertsTable.search('').columns(2).search('').draw();
            } else {
                alertsTable.columns(2).search(severity).draw();
            }
        });
    });
}

// Update alerts table with latest data
function updateAlerts() {
    if (!alertsTable) return;
    
    fetch('/api/alerts')
        .then(response => response.json())
        .then(data => {
            // Clear and load new data
            alertsTable.clear();
            alertsTable.rows.add(data).draw();
            
            // Update alert counts
            updateAlertCounts(data);
        })
        .catch(error => {
            console.error('Error fetching alerts:', error);
        });
}

// Update alert count badges
function updateAlertCounts(alerts) {
    const totalCount = alerts.length;
    const highCount = alerts.filter(a => a.severity === 'high').length;
    const mediumCount = alerts.filter(a => a.severity === 'medium').length;
    const lowCount = alerts.filter(a => a.severity === 'low').length;
    
    // Update the count badges
    document.getElementById('totalAlertsBadge').textContent = totalCount;
    document.getElementById('highAlertsBadge').textContent = highCount;
    document.getElementById('mediumAlertsBadge').textContent = mediumCount;
    document.getElementById('lowAlertsBadge').textContent = lowCount;
    
    // Update alert summary cards if they exist
    document.getElementById('totalAlertsCard')?.querySelector('.alert-count').textContent = totalCount;
    document.getElementById('highAlertsCard')?.querySelector('.alert-count').textContent = highCount;
    document.getElementById('mediumAlertsCard')?.querySelector('.alert-count').textContent = mediumCount;
    document.getElementById('lowAlertsCard')?.querySelector('.alert-count').textContent = lowCount;
}

// Clear all alerts
function clearAllAlerts() {
    if (confirm('Are you sure you want to clear all alerts? This action cannot be undone.')) {
        fetch('/api/alerts/clear', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Refresh the table
                updateAlerts();
                showToast('All alerts have been cleared');
            } else {
                showToast('Failed to clear alerts', 'danger');
            }
        })
        .catch(error => {
            console.error('Error clearing alerts:', error);
            showToast('Error clearing alerts', 'danger');
        });
    }
}

// Show toast notification
function showToast(message, type = 'success') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.setAttribute('id', toastId);
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Initialize and show the toast
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 3000
    });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}
