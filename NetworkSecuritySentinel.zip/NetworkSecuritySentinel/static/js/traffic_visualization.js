// traffic_visualization.js - Traffic visualization functionality

document.addEventListener('DOMContentLoaded', function() {
    initTrafficCharts();
    
    // Set up refresh interval (every 10 seconds)
    setInterval(updateTrafficCharts, 10000);
});

let packetRateChart = null;
let protocolDistributionChart = null;
let packetTypesChart = null;

// Initialize traffic charts
function initTrafficCharts() {
    // Initialize packet rate chart
    if (document.getElementById('packetRateChart')) {
        const ctx = document.getElementById('packetRateChart').getContext('2d');
        packetRateChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [], // Will be filled with timestamps
                datasets: [{
                    label: 'Total Packets',
                    data: [],
                    borderColor: '#4e73df',
                    backgroundColor: 'rgba(78, 115, 223, 0.05)',
                    pointRadius: 3,
                    pointBackgroundColor: '#4e73df',
                    pointBorderColor: '#4e73df',
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: '#4e73df',
                    pointHoverBorderColor: '#4e73df',
                    pointHitRadius: 10,
                    pointBorderWidth: 2,
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: 'Packet Rate Over Time'
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Time'
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Packets'
                        },
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });
    }
    
    // Initialize packet types chart
    if (document.getElementById('packetTypesChart')) {
        const ctx = document.getElementById('packetTypesChart').getContext('2d');
        packetTypesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['TCP', 'UDP', 'ICMP', 'Other'],
                datasets: [{
                    label: 'Packet Types',
                    data: [0, 0, 0, 0],
                    backgroundColor: [
                        '#4e73df',
                        '#1cc88a',
                        '#f6c23e',
                        '#e74a3b'
                    ],
                    hoverBackgroundColor: [
                        '#2e59d9',
                        '#17a673',
                        '#dda20a',
                        '#be2617'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Packet Types'
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });
    }
    
    // Initialize protocol distribution chart
    if (document.getElementById('protocolDistributionChart')) {
        const ctx = document.getElementById('protocolDistributionChart').getContext('2d');
        protocolDistributionChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        '#4e73df',
                        '#1cc88a',
                        '#36b9cc',
                        '#f6c23e',
                        '#e74a3b',
                        '#858796'
                    ],
                    hoverBackgroundColor: [
                        '#2e59d9',
                        '#17a673',
                        '#2c9faf',
                        '#dda20a',
                        '#be2617',
                        '#6e707e'
                    ],
                    hoverBorderColor: "rgba(234, 236, 244, 1)",
                }],
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            padding: 20
                        }
                    },
                    title: {
                        display: true,
                        text: 'Protocol Distribution'
                    }
                },
                cutout: '70%',
            },
        });
    }
    
    // Initialize traffic data
    updateTrafficCharts();
}

// Update traffic charts with latest data
function updateTrafficCharts() {
    // Update packet rate chart with historical data
    fetch('/api/traffic/history')
        .then(response => response.json())
        .then(data => {
            if (packetRateChart && data.length > 0) {
                // Format timestamps
                const labels = data.map(entry => {
                    const date = new Date(entry.timestamp * 1000);
                    return date.toLocaleTimeString();
                });
                
                // Total packets
                const totalPackets = data.map(entry => entry.total_packets);
                
                // Update chart
                packetRateChart.data.labels = labels;
                packetRateChart.data.datasets[0].data = totalPackets;
                packetRateChart.update();
                
                // Create stacked packet types chart if we have at least one data point
                if (packetTypesChart && data.length > 0) {
                    const latestData = data[data.length - 1];
                    packetTypesChart.data.datasets[0].data = [
                        latestData.tcp_packets,
                        latestData.udp_packets,
                        latestData.icmp_packets,
                        latestData.other_packets
                    ];
                    packetTypesChart.update();
                }
            }
        })
        .catch(error => {
            console.error('Error fetching traffic history:', error);
        });
    
    // Update protocol distribution chart
    fetch('/api/traffic/stats')
        .then(response => response.json())
        .then(data => {
            if (protocolDistributionChart && data.protocol_distribution) {
                const protocolData = data.protocol_distribution;
                protocolDistributionChart.data.labels = Object.keys(protocolData);
                protocolDistributionChart.data.datasets[0].data = Object.values(protocolData);
                protocolDistributionChart.update();
            }
            
            // Update port activity table
            updatePortActivityTable('portActivityTable', data.port_activity);
            
            // Update source IP table
            updateTopIPsTable('topSourceIPsTable', data.top_source_ips);
            
            // Update destination IP table
            updateTopIPsTable('topDestinationIPsTable', data.top_destination_ips);
        })
        .catch(error => {
            console.error('Error fetching traffic stats:', error);
        });
}

// Update table with IP address data
function updateTopIPsTable(tableId, ipData) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    
    // Clear existing rows
    tbody.innerHTML = '';
    
    // Add new rows
    if (ipData && Object.keys(ipData).length > 0) {
        Object.entries(ipData).forEach(([ip, count]) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${ip}</td>
                <td class="text-right">${count}</td>
            `;
            tbody.appendChild(row);
        });
    } else {
        // No data
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="2" class="text-center">No data available</td>
        `;
        tbody.appendChild(row);
    }
}

// Update port activity table
function updatePortActivityTable(tableId, portData) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    
    // Clear existing rows
    tbody.innerHTML = '';
    
    // Add new rows
    if (portData && Object.keys(portData).length > 0) {
        Object.entries(portData).forEach(([port, count]) => {
            const row = document.createElement('tr');
            let protocol = 'Unknown';
            let portNumber = 'N/A';
            
            if (port.includes(':')) {
                [protocol, portNumber] = port.split(':');
            } else {
                portNumber = port;
            }
            
            row.innerHTML = `
                <td>${protocol}</td>
                <td>${portNumber}</td>
                <td class="text-right">${count}</td>
            `;
            tbody.appendChild(row);
        });
    } else {
        // No data
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="3" class="text-center">No data available</td>
        `;
        tbody.appendChild(row);
    }
}
