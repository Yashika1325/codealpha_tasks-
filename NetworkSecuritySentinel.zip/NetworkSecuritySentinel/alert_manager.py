import logging
import time
from models import Alert
from app import db

logger = logging.getLogger(__name__)

class AlertManager:
    def __init__(self):
        self.alerts = []
        self.alert_count = 0
        self.last_alert_time = 0
    
    def add_alert(self, alert_data):
        """
        Add a new alert to the system
        
        Args:
            alert_data: Dictionary containing alert information
        """
        try:
            # Create database alert object
            alert = Alert(
                rule_id=alert_data.get('rule_id'),
                rule_name=alert_data.get('rule_name'),
                severity=alert_data.get('severity', 'medium'),
                timestamp=alert_data.get('timestamp', int(time.time())),
                message=alert_data.get('message'),
                source_ip=alert_data.get('source_ip'),
                destination_ip=alert_data.get('destination_ip'),
                protocol=alert_data.get('protocol')
            )
            
            # Add to database
            db.session.add(alert)
            db.session.commit()
            
            # Update alert stats
            self.alert_count += 1
            self.last_alert_time = time.time()
            
            # Keep a local cache of recent alerts
            self.alerts.append(alert_data)
            if len(self.alerts) > 100:  # Keep only the 100 most recent
                self.alerts.pop(0)
            
            logger.info(f"Alert generated: {alert_data.get('message')}")
            
            return alert.id
        
        except Exception as e:
            logger.error(f"Error adding alert: {str(e)}")
            db.session.rollback()
            return None
    
    def get_recent_alerts(self, limit=20):
        """Get the most recent alerts"""
        try:
            recent_alerts = Alert.query.order_by(Alert.timestamp.desc()).limit(limit).all()
            return [
                {
                    'id': a.id,
                    'rule_id': a.rule_id,
                    'rule_name': a.rule_name,
                    'severity': a.severity,
                    'timestamp': a.timestamp,
                    'message': a.message,
                    'source_ip': a.source_ip,
                    'destination_ip': a.destination_ip,
                    'protocol': a.protocol
                }
                for a in recent_alerts
            ]
        except Exception as e:
            logger.error(f"Error retrieving alerts: {str(e)}")
            return []
    
    def get_alert_count(self, time_period=3600):
        """Get count of alerts in the specified time period"""
        try:
            cutoff_time = int(time.time()) - time_period
            count = Alert.query.filter(Alert.timestamp >= cutoff_time).count()
            return count
        except Exception as e:
            logger.error(f"Error counting alerts: {str(e)}")
            return 0
    
    def get_alert_summary(self):
        """Get summary of alert activity"""
        try:
            # Count alerts by severity in the last 24 hours
            cutoff_time = int(time.time()) - 86400  # 24 hours
            
            total_count = Alert.query.filter(Alert.timestamp >= cutoff_time).count()
            high_count = Alert.query.filter(Alert.timestamp >= cutoff_time, 
                                          Alert.severity == 'high').count()
            medium_count = Alert.query.filter(Alert.timestamp >= cutoff_time, 
                                            Alert.severity == 'medium').count()
            low_count = Alert.query.filter(Alert.timestamp >= cutoff_time, 
                                         Alert.severity == 'low').count()
            
            # Get most common alert types
            # This would be more sophisticated in a real system
            # but for simplicity, we're just using basic counts
            
            return {
                'total_alerts': total_count,
                'high_severity': high_count,
                'medium_severity': medium_count,
                'low_severity': low_count,
                'last_alert_time': self.last_alert_time
            }
        
        except Exception as e:
            logger.error(f"Error generating alert summary: {str(e)}")
            return {
                'total_alerts': 0,
                'high_severity': 0,
                'medium_severity': 0,
                'low_severity': 0,
                'last_alert_time': 0
            }
